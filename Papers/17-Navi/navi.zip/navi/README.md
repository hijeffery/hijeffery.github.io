# Navi

Navigation with a Panorama camera. 

# Usage:

1. get frames:

    using vlc player. 

    > preprocess/video2frame_vlc.sh

2. rotate to different class images:

    > matlab -nodesktop preprocess/rotate.m

3. get image index:

    > cp names.sh path/to/data
    > cd path/to/data
    > ./names.sh

    run `names.sh` in the dataset folder. png images on the same path and subfolder will be indexed. 

4. fix dataset path into `load_Pano_v*.lua`

5. run train-test process `run.sh` and enjoy.

6. For simulation navigation: run 'preprocess/rotate_pano_sequence'; then 'featuremap/test_pretrained_v7_sequential.lua'.	

7. For simulation navigation: choose the sequence clip, and get sequence name with 'preprocess/img_names_rel.sh'. Then, run 'featuremap/test_pretrained_v7_sequential.lua'.	 Finally, use 'drawlabel.m' for GT and predictions.

