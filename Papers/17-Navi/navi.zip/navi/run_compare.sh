#! /bin/bash

# This is for the running of comparative models on the dataset.
# th -i comparemodel.lua -trsz 3000 -maxiter 5000 -cuda 1 -batchsize 10 -lr 1e-5 -model 4 -numclasses 7
th -i trainNiN.lua -trsz 3000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-5 -model 4 -numclasses 7