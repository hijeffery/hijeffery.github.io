-- model2.lua
-- benchmark model, from : 
-- A Machine Learning Approach to Visual Perception of Forest Trails for Mobile Robots
-- ReLU

function loadmodel2(numclasses)
	-- body
	local filter_size = 4
	local numclasses = numclasses or params.numclasses

	model = nn.Sequential()

	model:add(nn.SpatialConvolutionMM(3,32,filter_size,filter_size))
	model:add(nn.ReLU())
	-- model:add(nn.SpatialContrastiveNormalization(32, neighborhood, 1))
	model:add(nn.SpatialMaxPooling(2,2,2,2))

	model:add(nn.SpatialConvolutionMM(32,32,filter_size,filter_size))
	model:add(nn.SpatialMaxPooling(2,2,2,2))
	model:add(nn.ReLU())

	model:add(nn.SpatialConvolutionMM(32,32,filter_size,filter_size))
	model:add(nn.SpatialMaxPooling(2,2,2,2))
	model:add(nn.ReLU())

	model:add(nn.SpatialConvolutionMM(32,32,filter_size,filter_size))
	model:add(nn.SpatialMaxPooling(2,2,2,2))
	model:add(nn.ReLU())

	model:add(nn.Reshape(32*3*3))
	model:add(nn.Linear(32*3*3, 200))
	model:add(nn.ReLU())

	model:add(nn.Linear(200, numclasses))
	-- model:add(nn.Tanh())

	model:add(nn.LogSoftMax())

	-- print(model)

	-- confusion = optim.ConfusionMatrix(3)

	-- criterion = nn.ClassNLLCriterion()

	return model
end