-- VGG-S model
function loadmodel5()
	-- input: 224x224
	-- output: 1000x1

	local model = loadcaffe.load('model/VGG-CNN-S/VGG_CNN_S_deploy.prototxt', 'model/VGG-CNN-S/VGG_CNN_S.caffemodel')

	return model
end