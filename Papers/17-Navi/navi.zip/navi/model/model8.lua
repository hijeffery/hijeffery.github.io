-- NiN model
function loadmodel4()

	local model = loadcaffe.load('model/NiN/deploy.prototxt', 'model/NiN/nin_imagenet.caffemodel')

	return model
end