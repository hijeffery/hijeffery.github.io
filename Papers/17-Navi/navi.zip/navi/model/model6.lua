-- AlexNet-sal model
function loadmodel6()
	-- input: 227x227
	-- output: 5x1

	local model = loadcaffe.load('model/AlexNet/deploy.prototxt', 'model/AlexNet/AlexNet_SalObjSub.caffemodel')

	return model
end