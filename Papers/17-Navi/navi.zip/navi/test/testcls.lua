-- test.lua
-- run reconstruction 
-- save compresed test images. 

function testcls( model_input, data, label)
	local model = model_input
	local batchsize = params.batchsize
	local batches,idxs = makeminibatches(data, batchsize)
	local batchlabel = makeminibatches(label, batchsize, idxs)

	if cuda_enable then
		batches = batches:cuda()
	end

	local numbatches = batches:size(1)
	local confusion = optim.ConfusionMatrix(params.numclasses)
	confusion:zero()

	for i = 1, numbatches do
		predt = model:forward(batches[i])
		for j = 1, batchsize do
			confusion:add(predt[j], batchlabel[i][j])
		end
	end

	print(confusion)
end