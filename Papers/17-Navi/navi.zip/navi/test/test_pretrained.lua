-- test pretrained model with specific dataset

require './utils/init.lua'

print(arg[1], arg[2])

if arg[1] then
	model = torch.load(arg[1])
else
	model = torch.load('model.net')
end

if arg[2] then
	testfolder = arg[2]
else
	testfolder = '/home/lran/data/navigation-homo/clip3'
end

local imgnames = readtxt(testfolder .. '/jpgnames.txt')

local numtest = #imgnames

if numtest == 0 then 
	printred('Wrong Path ...')
else
	print('Totally ' .. numtest .. ' images in the test dataset.')
end

traindata = torch.Tensor(numtest, 3, 101, 101)
LABELs = torch.Tensor(numtest)

local lc = 0; rc = 0; sc = 0; tc = 0;

for i = 1, numtest do
    xlua.progress(i, numtest)

	local img_name = imgnames[i];

	local img = image.load(img_name);
	img = image.scale(img,101,101)
	img = image.rgb2yuv(img)
	traindata[i]:copy(img)
	
	-- train data
	if string.find(img_name, 'left') then
		lc  = lc + 1;
		LABELs[i]= 1;
	elseif string.find(img_name, 'front') then
		sc = sc +1;
		LABELs[i]= 2;
	elseif string.find(img_name, 'right') then
		rc = rc + 1;
		LABELs[i]= 3;
	else
		assert('Image does not exist!!!!!')
	end
end

traindata = normalizeimgs(traindata)
traindata = centralcrop(traindata)
traindata = traindata:cuda()

print(lc, sc, rc);
print(numtest, lc+rc+sc)

local confusionMat = optim.ConfusionMatrix(3)

for i = 1, numtest do
	local img = traindata[i]
	x = model:forward(img)
	confusionMat:add(x, LABELs[i])
end

print(confusionMat)