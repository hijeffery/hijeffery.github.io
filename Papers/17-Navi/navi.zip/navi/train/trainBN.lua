-- config:
-- batch Normalization models. 
-- remeber to load sgd params as well if pretrained.
-- 
function traincnn(model_in, dataset, dst, criterion, sgd_params)
	local model = model_in
	local dst = dst or dataset:clone()

	criterion = criterion or nn.MSECriterion()	
	-- criterion.sizeAverage = false;
	if cuda_enable then
		model = model:cuda()
		criterion = criterion:cuda()
	end

	if not sgd_params then
		sgd_params = {
		   learningRate = params.lr,
		   learningRateDecay = 1e-4,
		   weightDecay = params.weightDecay,
		   momentum = params.momentum,
		   evalCounter = params.evalCounter
		}
	end

	local feval = function(w_new)   -- works on batch sample.
	     if w~=w_new then
	            w:copy(w_new)
	     end

	    local loss = 0
	    dl_dw:zero()

	    local predts = model:forward(batchdata)
	    local loss = criterion:forward(predts, dstdata)
	    local dl_do = criterion:backward(predts, dstdata)
	    model:backward(batchdata, dl_do)

	     -- return loss(x) and dloss/dx
		return loss/batchsize, dl_dw:div(batchsize)
	end

	-- make mini-batch
	w,dl_dw = model:getParameters()
	w_old = w:clone()
	local epoch = params.maxiter
	local ninstance = dataset:size(1)
	batchsize = params.batchsize
	batches, idxs = makeminibatches(dataset, batchsize)
	batches_dst = makeminibatches(dst, batchsize, idxs)

	if cuda_enable then
		batches = batches:cuda()
		batches_dst = batches_dst:cuda()
	end
	local numbatches = batches:size(1)

	local idxs = torch.randperm(ninstance)

    local old_loss = 1e10
	for i = 1,epoch do
	    -- this variable is used to estimate the average loss
	    local current_loss = 0
	    local current_dw = torch.Tensor(w:size())
	    
	    if cuda_enable then
	    	current_dw = current_dw:cuda()
	    end
	 
	    -- an epoch is a full loop over our training data
	    for j = 1,numbatches do
	   		batchdata = batches[j]
	   		dstdata = batches_dst[j]
	    	-- w_update,fs = optim.sgd(feval,w,sgd_params)
	    	w_update,fs = optim.adagrad(feval,w,sgd_params)
	    	current_loss = current_loss + fs[1]
	    	current_dw:copy(w_update):add(w_old:mul(-1));
	    	w_old:copy(w_update)
	    end

	    -- report average error on epoch
	    current_loss = current_loss / numbatches
	    current_dw = current_dw:norm()
	    print('current loss in iter ' .. i .. ' = ' .. current_loss)
		
		if math.fmod(i,500) == 0 then
			sgd_params.learningRate = sgd_params.learningRate *10 
			sgd_params.momentum = 0.9
		end

		params.trainw[i] = w_old:norm()
		params.trainDw[i] = current_dw
		params.trainLoss[i]= current_loss

		logger:add{current_loss}

		if math.abs(old_loss - current_loss) < 1e-6 then
			print("Early break at iteration " .. i .. ".")
			break
		else
			old_loss = current_loss
		end

	end

	return model
end