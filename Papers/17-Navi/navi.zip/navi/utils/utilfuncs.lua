-- ============ FILE OPERATIONS: ====================
utilsr = {}
function utilsr.hist(data)
	-- body
	gnuplot.figure()
	gnuplot.hist(data)
end

-- ============ Data I/O ============================
function readtxt(txtname)
	-- read line by line, works for files like image names.
	local names = txtname
	local filenames = {}
	
	if paths.filep(names) then
		local file = io.open(names, 'r')
		for line in file:lines() do
			table.insert(filenames, line)
		end
	else
		assert('Folder do not exist ...\n')
	end
	return filenames
end

function save(data, filename, type)
	-- save Tensor to files like t7, hdf5, etc.
	if not string.find(torch.type(data), 'Tensor') then
		assert(false, '\n Useage Hit: Tensor expected, got ' .. torch.type(data) ..'\n')
	end

	local type = type or 't7'

	if type == 't7' then
		torch.save(filename .. '.t7', data)
	elseif type == 'hdf5' or type == 'h5' then
		local file = hdf5.open(filename .. '.h5', 'w')
		file:write('/data', data);  -- file:write('/data', x);
		file:close();	
	end
end

-- ============ Preprocessing =======================
function zca_whiten(x)
	-- do zca_whiten on image patches. N*D
	local dims = x:size()
	local nsamples = dims[1]
	local ndims    = dims[2]
	local M = torch.mean(x, 1)
	local D, V = unsup.pcacov(x)
	x:add(torch.ger(torch.ones(nsamples), M:squeeze()):mul(-1))
	local diag = torch.diag(D:add(0.1):sqrt():pow(-1))
	local P = V * diag * V:t()
	x = x * P
	return x, M, P
end

-- ============Other funcs ===========================

-- alf ls() nice function!
function utilsr.ls(path) return sys.split(sys.ls(path),'\n') end

function file_exists(name)
	if not paths.filep(name) then 
		return false
	else 
		return true 
	end
end

function path_exists(name)
	if not paths.dirp(name) then
		return false
	else
		return true
	end
end

function is_file(path)
    return paths.filep(path) or paths.dirp(path)
end

function savemodel(modelname,model)
	cleanupModel(model)
	torch.save(modelname, model)
end

function plot(losstable, name, sparse_scale)
	if type(losstable) == 'table' then
		losstable = torch.Tensor(losstable)
	end

	-- TODO : change this to average value.
	if sparse_scale then
		local tabel_sample = {}
		local scale = losstable:size(1)/(params.maxiter)
		for i = 1, params.maxiter do 
			table.insert(tabel_sample, losstable[i*scale])
		end
		losstable = torch.Tensor(tabel_sample)
	end
	
	-- plot 
	local figname = name or 'trainerrors'
	local fignameful = params.rundir ..'/' .. figname .. '.png'
	gnuplot.pngfigure(fignameful)
	gnuplot.plot({'Loss Table',losstable})
	gnuplot.xlabel('epoch')
	gnuplot.ylabel('*** loss')
	gnuplot.grid(true)
	gnuplot.title(figname)
	gnuplot.plotflush()  -- ensure that all outputs is written to the file properly.
end

function plothist(data, figname)
	-- body
	local figname = figname.. '.png' or 'hist.png'
	gnuplot.pngfigure(figname)
	gnuplot.hist(data)
	gnuplot.plotflush()
end

function plotheat(data, figname)
	local figname = figname .. '.png' or 'heatmap.png'
	gnuplot.pngfigure(figname)
	gnuplot.imagesc(data, 'color')
	gnuplot.plotflush()
end

-- function plots(curves, figname)
-- 	-- save curves to given name, figname
-- 	local figname = figname or 'Compare_curves'
-- 	gnuplot.pngfigure(figname)
-- 	gnuplot.xlabel('epoches')
-- 	gnuplot.ylabel('**loss')
-- 	gnuplot.grid(true)
-- 	gnuplot.figname(figname)
-- 	local tabels = {}
-- 	for i,k in ipairs curves do
-- 		table.instert(tables, {i,k})
-- 	end
-- 	gnuplot.plotflush()
-- end
-- ============== image and display ====================
function imshow( img )
	print('Warning: imshow needs qlua or localhost support to work well.\n')
	disp.image(img)
end

function imread( filename )
	-- body
	local img = image.load(filename)
	return img
end

-- save image to file, range (0,1), default name tmp.jpg
function imwrite(img, imgname)
	assert(type(imgname) == 'string', '\n ======== \n Usage(Tensor, image name). \n ============= \n')
	local imgname = imgname or 'tmp.jpg'

	--rerange to 0/1
	local min = img:min()
	local max = img:max()
	local img_01 = img:clone()
	if max-min ~= 0 then 
		img_01 = img_01:add(-min):div(max-min)
	end
	
	image.save(imgname,img_01)
end

function imresize(img, h, w)
	-- body
	local imgx = image.scale(img, h, w)
	return imgx
end

function attr( thx )
	-- attributes of tensor thx
	print('Tensor size= : ', thx:size())
	print('Value range= : ', thx:min(), thx:max()) 
end

function showweight(w, savepath)
	-- body
	local nInstance = w:size(1)
	
	if w:dim() == 2 then
		local wsize = math.sqrt(w:size(2))
		w2show = torch.Tensor(nInstance,wsize,wsize)
		for i=1, nInstance do
			w2show[i]:copy(w[i]:view(wsize,wsize))
		end
	else
		w2show = w
	end

	local dd = image.toDisplayTensor{input= w2show,
	                           padding=2,
	                           nrow=math.floor(math.sqrt(nInstance)),
	                           symmetric=true}
	if not savepath then
		imshow(dd)
	else	                           
		imwrite(dd,savepath)
	end

	-- release :
	w2show = nil

	return dd
end
-- ================= debug ==========================
function next()
   local answer = nil
   while answer ~= '' and answer ~= 'y' and answer ~= 'Y' and neverstall ~= true do
      io.write("continue ([y]/n/!)? ")
      io.flush()
      answer=io.read()
      if answer == '!' then
         neverstall = true
      end
      if answer == 'n' then
         print('exiting...')
         os.exit()
      end
   end
   print ''
end

function printred( string )
	-- print string with color
	print(sys.COLORS.red .. string)
end

-- =============== MODEL SIMPLIFY =======================
function zeroDataSize(data)
  if type(data) == 'table' then
    for i = 1, #data do
      data[i] = zeroDataSize(data[i])
    end
  elseif type(data) == 'userdata' then
    data = torch.Tensor():typeAs(data) -- an empty tensor with same data type as data;
  end
  return data
end

-- Resize the output, gradInput, etc temporary tensors to zero (so that the on disk size is smaller)
function cleanupModel(node)
  if node.output ~= nil then
    node.output = zeroDataSize(node.output)
  end
  if node.gradInput ~= nil then
    node.gradInput = zeroDataSize(node.gradInput)
  end
  if node.finput ~= nil then
    node.finput = zeroDataSize(node.finput)
  end
  -- Recurse on nodes with 'modules'
  if (node.modules ~= nil) then
    if (type(node.modules) == 'table') then
      for i = 1, #node.modules do
        local child = node.modules[i]
        cleanupModel(child)
      end
    end
  end

  -- Clear the references to the spatial convolution outputs as well
  if _spatial_convolution_mm_out ~= nil then
    _spatial_convolution_mm_out = {}
  end

  if _spatial_convolution_mm_gradout ~= nil then
    _spatial_convolution_mm_gradout = {}
  end

  collectgarbage()
end

-- ======== =  =PREPROCESSING  ==
function normalizeimg(inputimg)     -- wrong, ch1 == ch2 == ch3;
	local img = inputimg:clone()
	if img:size(1) == 1 then
		local lmean = img:mean()
		local lstd = img:std()
		img:add(-lmean)
		img:div(lstd)
		return img
	else
		normalization = nn.SpatialContrastiveNormalization(1, image.gaussian1D(7)):float()
		local yuv = image.rgb2yuv(img)
		-- normalize y locally:
		yuv[1] = normalization(yuv[{{1}}])

		-- -- normalize y globally:
		-- mean_y = img[1]:mean()
		-- std_y = img[1]:std()
		-- img[1]:add(-mean_y)
		-- img[1]:div(std_y)

		-- normalize u globally:
		mean_u = img[2]:mean()
		std_u = img[2]:std()
		img[2]:add(-mean_u)
		img[2]:div(std_u)
		-- normalize v globally:
		mean_v = img[3]:mean()
		std_v = img[3]:std()
		img[3]:add(-mean_v)
		img[3]:div(std_v)

		return img
	end
end

function normalizeimgs( imgs )
	-- body
	local imgn = torch.Tensor(imgs:size())

	print('Normalizing images ...')
	for i = 1,imgs:size(1) do
		xlua.progress(i,imgs:size(1))
		imgn[i]:copy(normalizeimg(imgs[i]))
	end
	return imgn
end

function normalizeyuv(batchdata, mean, std)
	-- normalize YUV image. Y locally, U,V globally.
	local mean = mean 
	local std = std;
	local channels = {'y','u','v'}

	if not mean then
		mean = {}
		std = {}

		for i, channel in ipairs(channels) do
			mean[i] = batchdata[{{},i,{},{}}]:mean()
			std[i] = batchdata[{{},i,{},{}}]:std()
		end
	end

	-- normalize Y, U, V channel globally
	for i,channel in ipairs(channels) do
	   -- normalize each channel globally:
	   batchdata[{ {},i,{},{} }]:add(-mean[i])
	   batchdata[{ {},i,{},{} }]:div(std[i])
	end

	-- locally normalize Y channel
	-- Define the normalization neighborhood:
	local neighborhood = image.gaussian1D(13)

	-- Define our local normalization operator (It is an actual nn module, 
	-- which could be inserted into a trainable model):
	local normalization = nn.SpatialContrastiveNormalization(1, neighborhood, 1)

	local batchnormalized = torch.Tensor(batchdata:size())
	for i = 1, batchnormalized:size(1) do
		batchnormalized[{i, {1}, {}, {}}]:copy(normalization:forward(batchdata[{i, {1}, {}, {}}]))
	end

	return batchnormalized, mean, std
end

function normalizehyper(vecs, mean, std)
	-- normalize hyperspectral 3x3 patches
	local vecs = vecs:clone()
	local mean = mean or vecs:mean()
	local std = std or vecs:std()

	vecs:add(-mean):div(std)

	return vecs, mean, std
end

function normalizehyperspec(data)
	local data = data:clone()
	local ndims = data:nDimension()
	local nInstance = data:size(1)
	for i = 1, nInstance do
		local datax = data[{i,{}}]
		local mean = datax:mean()
		local std = datax:std()
		datax:add(-mean):div(std)
	end

	return data
end

-- pixel_wise normalization
function normalpixel(vecs)	
	local vecs = vecs:clone()
	-- body
	local nInstance = vecs:size(1)
	local nDims = vecs:size(2)

	local meanvec = torch.mean(vecs,1)
	local stdvec  = torch.std(vecs,1)

	local meanvecn = torch.repeatTensor(meanvec,nInstance,1)
	local stdvecn  = torch.repeatTensor(stdvec ,nInstance,1)

	local vecsn = vecs:add(-meanvecn):cdiv(stdvecn)

	return vecsn
end

function convert2vec(data)
	local nInstance = data:size(1)

	if data:dim() == 4 then
		local nchnl = data:size(2)
		local h = data:size(3)
		local w = data:size(4)
		
		dataM = torch.Tensor(nInstance,1,h,w)
		if nchnl == 3 then
			for i = 1, nInstance do
				dataM[i] = image.rgb2y(data[i]) 
			end
		else
			dataM = data:clone()
		end
	else
		dataM = data:clone()
	end

	local length = dataM:nElement()/nInstance
	local data_vec = torch.Tensor(nInstance, length)

	for i = 1,nInstance do
		data_vec[i]:copy(dataM[i]:view(length))
	end

	return data_vec
end

function conv2img(data)
	-- input: 100X100
	if data:dim() == 2 then
		local datax = data:view(1,data:size()):clone()
	end
	return datax	
end

-- make minibatches with given seeds.
function makeminibatches(data, batchsize, idxs)
	-- body
	local nInstance = data:size(1)
	local numbatches = math.floor(nInstance/batchsize) 
	local idxs = idxs or torch.randperm(nInstance)

	if data:dim() == 1 then
		DATABATCH = torch.Tensor(numbatches, batchsize)

		for i = 1, numbatches do
			for j = 1,batchsize do
				local idx = (i-1)*batchsize + j
				DATABATCH[i][j] = data[idxs[idx]]
			end
		end

		return DATABATCH, idxs
		
	elseif data:dim() == 2 then
		DATABATCH = torch.Tensor(numbatches, batchsize, data:size(2))
	elseif data:dim() == 3 then
		DATABATCH = torch.Tensor(numbatches, batchsize, data:size(2), data:size(3))	
	elseif data:dim() == 4 then
		DATABATCH = torch.Tensor(numbatches, batchsize, data:size(2), data:size(3), data:size(4))	
	elseif data:dim() == 5 then
		DATABATCH = torch.Tensor(numbatches, batchsize, data:size(2), data:size(3), data:size(4), data:size(5))	
	else
		print('2D, 3D or 4D data expected .')
	end

	for i = 1, numbatches do
		for j = 1,batchsize do
			local idx = (i-1)*batchsize + j
			DATABATCH[i][j]:copy(data[idxs[idx]])
		end
	end

	local batches = DATABATCH:clone()

	-- collectgarbage
	DATABATCH=nil
	
	return batches, idxs
end

function toprobability(data)
	-- body
	local x2 = torch.cmul(data,data)* (-0.5)
	
	local p = torch.exp(x2):div(math.sqrt(2*3.14))

	return p
end

function chi2distance(x,y,nbins)
	local dim1 = x:dim()
	local dim2 = y:dim()
	local nbins = nbins or 20
	if dim1 ~= dim2 then
		error('Dim do not match');
	else	
		if dim1 == 1 then
			local hx = torch.histc(x,nbins)
			local hy = torch.histc(y,nbins)
			local a = hx - hy;
			local a1 = torch.cmul(a,a)
			local b = hx + hy;
			local c = torch.cdiv(a1,b);

			return c:sum()
		elseif dim1 == 2 then
			local nInstance = x:size(1)
			local hx = torch.zeros(nInstance,nbins)
			local hy = torch.zeros(nInstance,nbins)

			for i = 1,nInstance do

				local hxi = torch.histc(x[i],nbins)
				local hyi = torch.histc(y[i],nbins)

				hx[i]:copy(hxi)
				hy[i]:copy(hyi)
			end

			local a = hx - hy;
			local a1 = torch.cmul(a,a)
			local b = hx + hy;
			local c = torch.cdiv(a1,b);

			return c:sum(2)
		else
			error('vector or 2D tensor(N*D) expected.')
		end
	end
end
-- ===============================OLD FUNCITONS=============================================================================
-- ==========================
function loadtrainingdata( datasetname )
	if datasetname == 'horse' then
		gtpath = '/home/lran/data/weizmann_horse_db/figure_ground/'
		srcpath = '/home/lran/data/weizmann_horse_db/rgb/'

		horsedata = {}
		horselabel = {}
		for idx = 1,328 do
			local imname = string.format('horse%03d.jpg', idx)
			
			local imgsrc = image.load(srcpath ..  imname)
			imgsrc = image.scale(imgsrc, 200, 200)
			imgsrc = normalizeimg(imgsrc)
			table.insert(horsedata, imgsrc) 

			local imggt = image.load(gtpath .. imname)
			imggt = image.scale(imggt, 200, 200)
			imggt = nn.SpatialMaxPooling(2,2,2,2):forward(imggt)
			table.insert(horselabel, imggt)
		end		
		return horsedata, horselabel
	else
		error(datasetname .. 'not found.')
	end
end

function loadtrainingdata_originsize( datasetname )
	if datasetname == 'horse' then
		gtpath = '/home/lran/data/weizmann_horse_db/figure_ground/'
		srcpath = '/home/lran/data/weizmann_horse_db/rgb/'

		horsedata = {}
		horselabel = {}
		for idx = 1,328 do
			local imname = string.format('horse%03d.jpg', idx)
			
			local imgsrc = image.load(srcpath ..  imname)
			imgsrc = normalizeimg(imgsrc)
			table.insert(horsedata, imgsrc) 

			local imggt = image.load(gtpath .. imname)
			imggt = nn.SpatialMaxPooling(2,2,2,2):forward(imggt)
			table.insert(horselabel, imggt)
		end		
		return horsedata, horselabel
	else
		error(datasetname .. 'not found.')
	end
end

function loadhorsedata()
	imgsize = params.imgsz;
	horsedata = torch.Tensor(328,imgsize,imgsize):zero()
	horselabel = torch.Tensor(328,imgsize,imgsize):zero()

	for idx = 1,328 do
		imname = string.format('./horse/figure_ground/horse%03d.jpg', idx)
		img = image.load(imname)
		img2 = image.scale(img,imgsize,imgsize)
		horselabel[{{idx}, {}}] = torch.Tensor(imgsize,imgsize):copy(img2)
		
		imname = string.format('./horse/gray/horse%03d.jpg',idx)
		img = image.load(imname)
		img2 = image.scale(img,imgsize,imgsize)
		img2 = normalizeimg(img2)
		horsedata[{{idx},{}}] = torch.Tensor(imgsize,imgsize):copy(img2)
	end

	return horsedata, horselabel
end

function loadhorsedata_table()
	-- load image into tables
	local imgsize = 260 or params.imgsz
	local horsedata = {}
	local horselabel = {}

	local datasz = 328 or params.datasz
	for idx = 1, datasz do
		local imname = string.format('./horse/figure_ground/horse%03d.jpg', idx)
		local img = image.load(imname)
		local img2 = image.scale(img,imgsize,imgsize)
		horselabel[idx] = img2

		imname = string.format('./horse/gray/horse%03d.jpg',idx)
		img = image.load(imname)
		img2 = image.scale(img,imgsize,imgsize)

		-- img2 = normalizeimg_contrastive(img2:float())
		-- horsedata[idx] = img2:double()

		img2 = normalizeimg(img2)
		horsedata[idx] = img2
	end

	return horsedata,horselabel
end

function loadhorsedata_table_max()
	-- load image into tables, do not need to pool labels again.
	local imgsize = params.imgsz
	local horsedata = {}
	local horselabel = {}

	for idx = 1,params.datasz do
		local imname = string.format('./horse/figure_ground_max/horse%03d.jpg', idx)
		local img = image.load(imname)
		horselabel[idx] = img

		imname = string.format('./horse/gray/horse%03d.jpg',idx)
		img = image.load(imname)
		img2 = image.scale(img,imgsize,imgsize)
		-- img2 = normalizeimg_contrastive(img2:float())
		-- horsedata[idx] = img2:double()

		img2 = normalizeimg(img2)
		horsedata[idx] = img2
	end

	return horsedata,horselabel
end

function loadhorsedata_color_table_max()
	-- load image into tables, do not need to pool labels again.
	local imgsize = params.imgsz
	local horsedata = {}
	local horselabel = {}

	for idx = 1,params.datasz do
		local imname = string.format('./horse/figure_ground_max/horse%03d.jpg', idx)
		local img = image.load(imname)
		horselabel[idx] = img

		imname = string.format('./horse/rgb/horse%03d.jpg',idx)
		img = image.load(imname)
		img2 = image.scale(img,imgsize,imgsize)
		img2 = normalizeimg(img2)
		horsedata[idx] = img2
	end

	return horsedata,horselabel
end

function loadhorsedata_org_table()
	-- load image into tables
	-- do not change image size
	local imgsize = params.imgsz
	local horsedata = {}
	local horselabel = {}

	for idx = 1,params.datasz do
		local imname = string.format('./horse/figure_ground/horse%03d.jpg', idx)
		local img = image.load(imname)
		horselabel[idx] = img

		imname = string.format('./horse/gray/horse%03d.jpg',idx)
		img = image.load(imname)
		
		-- img2 = normalizeimg_divisive(img:float())
		-- img2 = normalizeimg_contrastive(img:float())
		-- horsedata[idx] = img2:double()

		img2 = normalizeimg(img)
		horsedata[idx] = img2
	end

	return horsedata,horselabel
end

function normalizeimg_contrastive(img)
	local neighborhood = image.gaussian1D(13)
	local normalization = nn.SpatialContrastiveNormalization(1, neighborhood, 1):float()
	img = normalization:forward(img)

	return img
end

function normalizeimg_divisive(img)
	local neighborhood = image.gaussian1D(13)
	local normalization = nn.SpatialDivisiveNormalization(1, neighborhood, 10):float()
	img = normalization:forward(img)

	return img
end

function paddingimg(dataset,pdsize)
   padimgs = torch.Tensor(params.datasz, params.imgsz+ 2*pdsize, params.imgsz+ 2*pdsize):zero()
   for i=1,params.datasz do
      local valuimg = padimgs[{{i},{pdsize+1,pdsize + params.imgsz},{pdsize+1,pdsize + params.imgsz}}]
      valuimg:copy(dataset[{{i},{}}])
   end
   return padimgs
end


function cropimg(indataset,filtersize)
	local fltsz = filtersize - 1
	Num = indataset:size()[1]
	Datadim = indataset:size()[2]
	local outdataset = torch.Tensor(Num,Datadim- fltsz,Datadim- fltsz):zero()
	for i = 1,Num do
		local img = indataset[{{i},{1+fltsz/2,Datadim-fltsz/2},{1+fltsz/2,Datadim-fltsz/2}}]
		outdataset[{{i},{}}] = torch.Tensor(Datadim-fltsz,Datadim-fltsz):copy(img)
	end

	return outdataset
end

function MaxpoolGT(img)
	local model = nn.SpatialMaxPooling(2,2,2,2)
	local img2 = model:forward(img)

	return img2
end

function nnTrain(model,dataset)
	trainer = nn.StochasticGradient(model, criterion)

	trainer.learningRate = 0.01
	trainer.maxIteration = 10

	trainer:train(dataset)

	return model
end

function trainmodels(model,dataset, sgd_params)
	w,dl_dw = model:getParameters()
	
	feval = function(w_new)   -- works on one sample.
	     if w~=w_new then
	            w:copy(w_new)
	     end

	     _nidx_ = (_nidx_ or 0) + 1
	     local num_dataset = params.trsz
	     if _nidx_ > num_dataset then _nidx_ = 1 end

	     -- local sample = dataset1[_nidx_]
	     -- local target = dataset[2][{{_nidx_},{}}]      -- this funny looking syntax allows
	     -- local inputs = dataset[1][{{_nidx_},{}}]    -- slicing of arrays.
	     local target = dataset[_nidx_][2]
	     local inputs = dataset[_nidx_][1]    

	     -- reset gradients (gradients are always accumulated, to accomodate 
	     -- batch methods)
	     dl_dw:zero()

	     -- evaluate the loss function and its derivative wrt w, for that sample
	     local loss_w = criterion:forward(model:forward(inputs), target)
	     model:backward(inputs, criterion:backward(model.output, target))

	     -- return loss(x) and dloss/dx
	     return loss_w, dl_dw
	end
	
	sgd_params = {
	   learningRate = params.rate,
	   learningRateDecay = 1e-4,
	   weightDecay = 0,
	   momentum = params.momentum,
	   evalCounter = params.evalCounter
	}

	-- we cycle 1e4 times over our training data
	epoch = params.maxiter
	num_dataset = params.trsz
	for i = 1,epoch do
	 
	   -- this variable is used to estimate the average loss
	   local current_loss = 0
	   local old_loss = 1e4
	 
	   -- an epoch is a full loop over our training data
	   for j = 1,num_dataset do
	 
	      -- optim contains several optimization algorithms. 
	      -- All of these algorithms assume the same parameters:
	      --   + a closure that computes the loss, and its gradient wrt to x, 
	      --     given a point x
	      --   + a point x
	      --   + some parameters, which are algorithm-specific
	       
	      _,fs = optim.sgd(feval,w,sgd_params)
	 
	      -- Functions in optim all return two things:
	      --   + the new x, found by the optimization method (here SGD)
	      --   + the value of the loss functions at all points that were used by
	      --     the algorithm. SGD only estimates the function once, so
	      --     that list just contains one value.
	 
	      current_loss = current_loss + fs[1]
	   end
	 
	   -- report average error on epoch
	   current_loss = current_loss / num_dataset
	   print('current loss in iter ' .. i .. ' = ' .. current_loss)
		
		if math.fmod(i,100) == 0 then 
		   modelsavename = params.rundir .. '/tmpfullmodel.net'
		   savemodel(modelsavename,model)
		end
		params.trainLoss[i]= current_loss
		if math.abs(old_loss - current_loss) < 1e-6 then
			break
		end
	end

	return model, params
end

function trainmodels_dmethds(model,dataset)
	w,dl_dw = model:getParameters()
	
	feval = function(w_new)   -- works on one sample.
	     if w~=w_new then
	            w:copy(w_new)
	     end

	     _nidx_ = (_nidx_ or 0) + 1
	     local num_dataset = params.trsz
	     if _nidx_ > num_dataset then _nidx_ = 1 end

	     -- local sample = dataset1[_nidx_]
	     -- local target = dataset[2][{{_nidx_},{}}]      -- this funny looking syntax allows
	     -- local inputs = dataset[1][{{_nidx_},{}}]    -- slicing of arrays.
	     local target = dataset[_nidx_][2]
	     local inputs = dataset[_nidx_][1]    

	     -- reset gradients (gradients are always accumulated, to accomodate 
	     -- batch methods)
	     dl_dw:zero()

	     -- evaluate the loss function and its derivative wrt w, for that sample
	     local loss_w = criterion:forward(model:forward(inputs), target)
	     model:backward(inputs, criterion:backward(model.output, target))

	     -- return loss(x) and dloss/dx
	     return loss_w, dl_dw
	end

	-- we cycle 1e4 times over our training data
	epoch = params.maxiter
	num_dataset = params.trsz
	local Loss = {}
	for i = 1,epoch do
	 
	   -- this variable is used to estimate the average loss
	   local current_loss = 0
	 
	   -- an epoch is a full loop over our training data
	   for i = 1,num_dataset do
	 
	      -- optim contains several optimization algorithms. 
	      -- All of these algorithms assume the same parameters:
	      --   + a closure that computes the loss, and its gradient wrt to x, 
	      --     given a point x
	      --   + a point x
	      --   + some parameters, which are algorithm-specific
	       
	      -- _,fs = optim.sgd(feval,w,sgd_params)
		-- optimize on current mini-batch
		if optimMethod == optim.asgd then
			_,fs,average = optimMethod(feval, w, optimState)
		else
			_,fs = optimMethod(feval, w, optimState)
		end
	      -- Functions in optim all return two things:
	      --   + the new x, found by the optimization method (here SGD)
	      --   + the value of the loss functions at all points that were used by
	      --     the algorithm. SGD only estimates the function once, so
	      --     that list just contains one value.
	 
	      current_loss = current_loss + fs[1]
	   end
	 
	   -- report average error on epoch
	   current_loss = current_loss / num_dataset
	   print('current loss = ' .. current_loss)
	   Loss[i] = current_loss
	end

	return model, Loss
end

function trainmodels_batch(model, dataset)
	trsize = params.trsz
	maxepoch = params.maxiter
	batchSize = params.batchSize

	w,dl_dw = model:getParameters()

	-- local vars
	local time = sys.clock()

	-- epoch tracker
	for epoch = 1, maxepoch do

		-- shuffle at each epoch, and copy images to mini-batch each epoch.
		shuffle = torch.randperm(trsize)

		-- do one epoch
		print('==> doing epoch on training data:')
		print("==> online epoch # " .. epoch .. ' [batchSize = ' .. batchSize .. ']')
		
		current_loss = 0
		for t = 1,trsize,batchSize do  --do one  batch 

			-- create mini batch
			local inputs = torch.Tensor(params.batchSize,1,params.datasz,params.datasz)
			local targets = torch.Tensor(params.batchSize)
			local k = 1
			for i = t,math.min(t+batchSize-1,trsize) do
				-- load new sample
				local input = dataset[shuffle[i]][1]
				local target = dataset[shuffle[i]][2]
				inputs[k] =  input
				targets[k] =  target
				k  = k + 1
			end

			next()
			local outputs = model:forward(inputs)
			next()

			-- create closure to evaluate f(X) and df/dX
			local feval = function(w_new)
				-- get new parameters
				if w_new ~= w then
				w:copy(w_new)
				end

				-- reset gradients
				dl_dw:zero()

				-- f is the average of all criterions
				local f = 0

				-- evaluate function for complete mini batch
				-- for i = 1,#inputs do
				-- 	-- estimate f
				-- 	local output = model:forward(inputs[i])
				-- 	local err = criterion:forward(output, targets[i])
				-- 	f = f + err

				-- 	-- estimate df/dW
				-- 	local df_do = criterion:backward(output, targets[i])
				-- 	model:backward(inputs[i], df_do)
				-- end
				local outputs = model:forward(inputs)
				local f = criterion:forward(outputs,targets)

				-- -- penalties (L1 and L2):
				-- if opt.coefL1 ~= 0 or opt.coefL2 ~= 0 then
				-- -- locals:
				-- local norm,sign= torch.norm,torch.sign

				-- -- Loss:
				-- f = f + opt.coefL1 * norm(parameters,1)
				-- f = f + opt.coefL2 * norm(parameters,2)^2/2

				-- estimate df/dW
				local df_do = criterion:backward(outputs, targets)
				model:backward(inputs, df_do)

				-- normalize gradients and f(X)
				-- dl_dw:div(#inputs)
				
				-- return f and df/dX
				return f,dl_dw
			end   -- end of feval.

			sgd_params = {
				learningRate = params.lrate,
				learningRateDecay = 1e-4,
				weightDecay = 0,
				momentum = params.momentum
			}
			_,fs = optim.sgd(feval, w, sgd_params)

		    current_loss = current_loss + fs[1]

		end -- end of batch 
		current_loss = current_loss / batchSize
		print('current loss for epoch' .. epoch .. ' = ' .. current_loss)

	end -- end of epoch
	-- time taken
	time = sys.clock() - time
	time = time / trsize
	print("==> time to learn 1 sample = " .. (time) .. 's')

	return model
end

function getSNR(imgsrc, imgrcnt)
	local src = imgsrc:clone()
	local new = imgrcnt:clone()

	local residual = imgrcnt:clone():add(-src)

	local numerator = torch.dot(new,new)
	local denominator = torch.dot(residual,residual)

	return numerator/denominator
end


-- write to svm format file
function svmwrite(fname, data, label)
	print('Writing ' .. fname)
	local function vectostr(x)
		-- works on all values. Do not ignore zeros
		local str = {}
		local cntr = 1
		x:apply(function(v) 
			table.insert(str,string.format('%d:%g', cntr, v))
			cntr = cntr + 1
			return v
			end)
		return table.concat(str, ' ')
	end

	local batchdim = data:dim()

	local veclength = data:size(batchdim)
	local num_instance = data:nElement()/veclength

	local data = data:view(-1, veclength)

	-- make vec dim index
	local of = torch.DiskFile(fname,'w')
	for i=1, num_instance do
		local ex = label[i]

		local str = string.format('%g %s\n', ex, vectostr(data[i]))
		of:writeString(str)
	end
	of:close()
end

function isNaN(number)
	return number ~= number
end

function expandrange(ranges)
	-- expand overlap ranges
	local length = 0
	local rng_new = {}
	for i = 1, #ranges do
		local rng = ranges[i][2] - ranges[i][1] + 1
		table.insert(rng_new, {length+1, length+rng})
		length = rng + length
	end
	return length, rng_new
end
------------------------------------------------------------------------------------------
-- packaging
------------------------------------------------------------------------------------------
local utils = {}
utils.getSNR = getSNR

return utils