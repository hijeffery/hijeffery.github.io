-- loadPano.lua, load all images, then random split into test and train.
-- resize to 101 x 101 as the paper shows.

function loadPano(sequence_num, folderpath)
	local data_t7 = './data/pano_101_101_data.t7'
	local label_t7 = './data/pano_101_101_label.t7'
	local data_test_t7 = './data/pano_101_101_test_data.t7'
	local label_test_t7 = './data/pano_101_101_test_label.t7'

	local trainsize = sequence_num or 100

	if paths.filep(data_t7) then
		print('Loading data from disc ... ')
		IMGs = torch.load(data_t7)
		LABELs = torch.load(label_t7)
		IMGs_test = torch.load(data_test_t7)
		LABELs_test = torch.load(label_test_t7)

	else 
		local folderpath = '/home/lran/data/navigation-homo/'

		local names = folderpath .. 'jpgnames.txt'

		local file = io.open(names, 'r')
		local filenames = {}
		for line in file:lines() do
			table.insert(filenames, line)
		end

		local num_imgs = #filenames
		local idx_table = torch.randperm(num_imgs)

		-- prepare train data set
		local datasize = trainsize

		IMGs = torch.Tensor(datasize, 3, 101, 101)
		LABELs = torch.zeros(datasize)

		local lc = 0; rc = 0; sc = 0;

		for i = 1, datasize do
		    xlua.progress(i, datasize)

			local img_idx = idx_table[i];
			local img_name = filenames[img_idx];

			local img = image.load(img_name);
			img = image.scale(img,101,101)
			img = image.rgb2yuv(img)
			IMGs[i]:copy(img)
			
			-- train data
			if string.find(img_name, 'left') then
				lc  = lc + 1;
				LABELs[i]= 1;
			elseif string.find(img_name, 'front') then
				sc = sc +1;
				LABELs[i]= 2;
			elseif string.find(img_name, 'right') then
				rc = rc + 1;
				LABELs[i]= 3;
			else
				assert('Image does not exist!!!!!')
			end
		end

		print(lc, sc, rc);
		print(num_imgs, lc+rc+sc)
		
		torch.save(data_t7, IMGs)
		torch.save(label_t7, LABELs)

		-- prepare test data set 
		local test_num = 100
		IMGs_test = torch.Tensor(test_num, 3, 101, 101)
		LABELs_test = torch.zeros(test_num)

		local lc = 0; rc = 0; sc = 0;

		for i = trainsize + 1, trainsize + test_num do
		      xlua.progress(i-test_num, test_num)

			local img_idx = idx_table[i];
			local img_name = filenames[img_idx];

			local img = image.load(img_name);
			img = image.scale(img,101,101)
			img = image.rgb2yuv(img)
			IMGs_test[i-test_num]:copy(img)
			
			-- train data
			if string.find(img_name, 'lc') then
				lc  = lc + 1;
				LABELs_test[i-test_num]= 1;
			elseif string.find(img_name, 'sc') then
				sc = sc +1;
				LABELs_test[i-test_num]= 2;
			elseif string.find(img_name, 'rc') then
				rc = rc + 1;
				LABELs_test[i-test_num]= 3;
			else
				assert('Image does not exist!!!!!')
			end
		end

		print(lc, sc, rc);
		print(num_imgs, lc+rc+sc)
		
		torch.save(data_test_t7, IMGs_test)
		torch.save(label_test_t7, LABELs_test)
	end
	return IMGs, LABELs, IMGs_test, LABELs_test
end