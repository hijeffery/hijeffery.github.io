-- init.lua

require 'nn'
require 'cunn'
-- require 'cudnn'
require 'cutorch'
require 'sys'
require 'image'
require 'optim'
require 'paths'
-- require 'loadcaffe'
require 'gnuplot'

mat = require 'matio'

-- global config:
torch.manualSeed(2)  -- fix seed.
torch.setdefaulttensortype('torch.FloatTensor')
-- gnuplot.setterm('xterm')

-- load util functions
include 'centralcrop.lua'
include 'loaddata.lua'
include 'loadData.lua'
include 'loaddata_full.lua'
include 'loadPano.lua'
include 'loadPano_train_test.lua'
include 'loadPano_v5.lua'
include 'loadPano_v7.lua'
include 'utilfuncs.lua'

-- models:
include '../model/model0.lua'
include '../model/model1.lua'
include '../model/model2.lua'
include '../model/model3.lua'
include '../model/model4.lua'
include '../model/model5.lua'
include '../model/model6.lua'
 
-- train methods:
include '../train/trainBN.lua'

-- test :
include '../test/testcls.lua'