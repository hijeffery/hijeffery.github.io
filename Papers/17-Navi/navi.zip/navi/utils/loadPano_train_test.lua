-- loadPano_train_test.lua
-- given: Image lists
-- given: test image folder name
-- loadPano.lua, load all images, then randomly split
-- resize to 101 x 101 as the paper shows.

function loadPano_train_test(numtrain, leaveout_idx, width, height)
	local data_t7 = './data/pano_101_101_data.t7'
	local label_t7 = './data/pano_101_101_label.t7'
	local data_test_t7 = './data/pano_101_101_test_data.t7'
	local label_test_t7 = './data/pano_101_101_test_label.t7'

	local trainsize = numtrain
	local testfoldername = leaveout_idx or 'clip1'
	local width = width or 101
	local height = height or 101

	if paths.filep(data_test_t7) then
		print('Loading data from disc ... ')
		IMGs = torch.load(data_t7)
		LABELs = torch.load(label_t7)
		IMGs_test = torch.load(data_test_t7)
		LABELs_test = torch.load(label_test_t7)

		-- check if data meet demands
		local w = IMGs:nElement()
		if w ~= trainsize*3*width*height then
			print('Disc files do not meet request. Deleting ...')
			os.execute('rm data/*')
			print('Reloading data from source images: ')
			IMGs, LABELs, IMGs_test, LABELs_test = loadPano_train_test(numtrain, leaveout_idx, width, height)
		end

	else 
		print('Loading Images from sourse jpg/png files ... ')
		local folderpath = '/home/lran/data/navigation-homo/'

		local names = folderpath .. 'jpgnames.txt'

		local filenames = readtxt(names)

		local num_imgs = #filenames

		
		local idx_table = torch.randperm(num_imgs)

		-- prepare train data set
		local datasize = trainsize
		if datasize > num_imgs then
			datasize = num_imgs
		end

		IMGs = torch.Tensor(datasize, 3, height, width)
		LABELs = torch.zeros(datasize)

		local lc = 0; rc = 0; sc = 0; tc = 0;
		local trainc = 1;

		for i = 1, num_imgs do
		    xlua.progress(i, num_imgs)

			local img_idx = idx_table[i];
			local img_name = filenames[img_idx];

		   	if not string.find(img_name, testfoldername) then
				local img = image.load(img_name);
				img = image.scale(img,height, width)
				img = image.rgb2yuv(img)
				if img_full == 1 then
					img[{{},{1,50},{}}] = 0
				elseif img_full == 2 then
					img[{{},{52,101},{}}] = 0
				end	
				IMGs[trainc]:copy(img)
				
				-- train data
				if string.find(img_name, 'left') then
					lc  = lc + 1;
					LABELs[trainc]= 1;
				elseif string.find(img_name, 'front') then
					sc = sc +1;
					LABELs[trainc]= 2;
				elseif string.find(img_name, 'right') then
					rc = rc + 1;
					LABELs[trainc]= 3;
				else
					assert('Image does not exist!!!!!')
				end
				trainc = trainc + 1;
			else
				-- test
				tc = tc + 1;
			end

			-- check if we have enough train image 
			if trainc -1 == datasize then 
				break;
			end
		end

		print(lc, sc, rc);
		print(num_imgs, lc+rc+sc)
		
		torch.save(data_t7, IMGs)
		torch.save(label_t7, LABELs)

		-- =================================================================================
		-- prepare test data set 
		-- =================================================================================
		local test_num = tc
		IMGs_test = torch.Tensor(test_num, 3, height, width)
		LABELs_test = torch.ones(test_num)

		local lc = 0; rc = 0; sc = 0; tc = 0

		for i = 1, num_imgs do
		    xlua.progress(i, num_imgs)

			local img_idx = idx_table[i];
			local img_name = filenames[img_idx];

			if string.find(img_name, testfoldername) then
				tc = tc + 1 

				local img = image.load(img_name);
				img = image.scale(img, height, width)
				img = image.rgb2yuv(img)
				if img_full == 1 then
					img[{{},{1,50},{}}] = 0
				elseif img_full == 2 then
					img[{{},{52,101},{}}] = 0
				end	
				IMGs_test[tc]:copy(img)
			
				-- Label
				if string.find(img_name, 'left') then
					lc = lc + 1;
					LABELs_test[tc]= 1;
				elseif string.find(img_name, 'front') then
					sc = sc +1;
					LABELs_test[tc]= 2;
				elseif string.find(img_name, 'right') then
					rc = rc + 1;
					LABELs_test[tc]= 3;
				else
					assert('Image does not exist!!!!!')
				end
			end

			-- check if we have all the test image
			if tc == test_num then 
				break;
			end
		end

		print(lc, sc, rc);
		print(num_imgs, lc+rc+sc)
		
		torch.save(data_test_t7, IMGs_test)
		torch.save(label_test_t7, LABELs_test)
	end
	return IMGs, LABELs, IMGs_test, LABELs_test
end