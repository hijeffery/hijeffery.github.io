-- loadPano_train_test.lua
-- given: Image lists
-- given: test image folder name
-- loadPano.lua, load all images, then randomly split
-- resize to 101 x 101 as the paper shows.

function loadPano_v7(numtrain, leaveout_idx, width, height)
	local data_t7 = './data/pano_v7_data.t7'
	local label_t7 = './data/pano_v7_label.t7'
	local data_test_t7 = './data/pano_v7_test_data.t7'
	local label_test_t7 = './data/pano_v7_test_label.t7'

	local trainsize = numtrain
	local testfoldername = leaveout_idx or 'clip1'
	local width = width or 101
	local height = height or 101

	if paths.filep(data_test_t7) then
		print('Loading training data from disc ... ')
		IMGs = torch.load(data_t7)
		print('Loading training label from disc ... ')
		LABELs = torch.load(label_t7)
		print('Loading testing data from disc ... ')
		IMGs_test = torch.load(data_test_t7)
		print('Loading testing label from disc ... ')
		LABELs_test = torch.load(label_test_t7)

		-- check if data meet demands
		local w = IMGs:nElement()
		if w ~= trainsize*3*width*height then
			print('Disc files do not meet request. Deleting ...')
			os.execute('rm data/*')
			print('Reloading data from source images: ')
			IMGs, LABELs, IMGs_test, LABELs_test = loadPano_v7(numtrain, leaveout_idx, width, height)
		end

	else 
		print('Loading Images from sourse jpg/png files ... ')
		local p_folder = paths.home .. '/data/navigation-homo-v7/'

		local names = p_folder .. 'jpgnames.txt'

		local filenames = readtxt(names)

		local num_imgs = #filenames
		print('Total Images : ' , num_imgs)
		
		local idx_table = torch.randperm(num_imgs)

		-- prepare train data set
		local datasize = trainsize
		if datasize > num_imgs then
			datasize = num_imgs
		end

		IMGs = torch.Tensor(datasize, 3, height, width)
		LABELs = torch.zeros(datasize)

		local lc = 0; rc = 0; sc = 0; tc = 0; lc1 = 0; rc1 = 0; lc2 =0; rc2 = 0;
		local trainc = 1;

		for i = 1, num_imgs do
		    xlua.progress(i, num_imgs)

			local img_idx = idx_table[i];
			local img_name = filenames[img_idx];

		   	if not string.find(img_name, testfoldername) then
				local img = image.load(img_name);
				img = image.scale(img,height, width)
				img = image.rgb2yuv(img)
				if img_full == 1 then
					img[{{},{1,50},{}}] = 0
				elseif img_full == 2 then
					img[{{},{52,101},{}}] = 0
				end	
				IMGs[trainc]:copy(img)
				
				-- train data label
				if string.find(img_name, 'left2') then
					lc1  = lc1 + 1;
					LABELs[trainc]= 1;
				elseif string.find(img_name, 'left1') then
					lc2  = lc2 + 1;
					LABELs[trainc]= 2;
				elseif string.find(img_name, 'left') then
					lc = lc +1;
					LABELs[trainc]= 3;
				elseif string.find(img_name, 'front') then
					sc = sc + 1;
					LABELs[trainc]= 4;
				elseif string.find(img_name, 'right1') then
					rc1 = rc1 + 1;
					LABELs[trainc]= 6;
				elseif string.find(img_name, 'right2') then
					rc2 = rc2 + 1;
					LABELs[trainc]= 7;
				elseif string.find(img_name, 'right') then
					rc = rc + 1;
					LABELs[trainc]= 5;
				else
					assert('Image does not exist!!!!!')
				end
				trainc = trainc + 1;
			else
				-- test
				tc = tc + 1;
			end

			-- check if we have enough train image 
			if trainc -1 == datasize then 
				break;
			end
		end

		print(lc2, lc1, lc, sc, rc, rc1, rc2);
		print(num_imgs, lc+rc+sc+lc1+rc1+rc2+lc2);

		-- preprocess
		IMGs, mean_train, std_train = normalizeyuv(IMGs)
		IMGs = centralcrop(IMGs)
		
		torch.save(data_t7, IMGs)
		torch.save(label_t7, LABELs)

		-- =================================================================================
		-- prepare test data set 
		-- =================================================================================
		local test_num = tc
		IMGs_test = torch.Tensor(test_num, 3, height, width)
		LABELs_test = torch.ones(test_num)

		lc = 0; rc = 0; sc = 0; tc = 0; lc1 = 0; rc1 = 0; lc2 = 0; rc2 = 0;

		for i = 1, num_imgs do
		    xlua.progress(i, num_imgs)

			local img_idx = idx_table[i];
			local img_name = filenames[img_idx];

			if string.find(img_name, testfoldername) then
				tc = tc + 1 

				local img = image.load(img_name);
				img = image.scale(img, height, width)
				img = image.rgb2yuv(img)

				if img_full == 1 then
					img[{{},{1,50},{}}] = 0
				elseif img_full == 2 then
					img[{{},{52,101},{}}] = 0
				end	
				
				IMGs_test[tc]:copy(img)
			
				-- Label
				if string.find(img_name, 'left2') then
					lc1  = lc1 + 1;
					LABELs_test[tc]= 1;
				elseif string.find(img_name, 'left1') then
					lc2  = lc2 + 1;
					LABELs_test[tc]= 2;
				elseif string.find(img_name, 'left') then
					lc = lc +1;
					LABELs_test[tc]= 3;
				elseif string.find(img_name, 'front') then
					sc = sc + 1;
					LABELs_test[tc]= 4;
				elseif string.find(img_name, 'right1') then
					rc1 = rc1 + 1;
					LABELs_test[tc]= 6;
				elseif string.find(img_name, 'right2') then
					rc2 = rc2 + 1;
					LABELs_test[tc]= 7;
				elseif string.find(img_name, 'right') then
					rc = rc + 1;
					LABELs_test[tc]= 5;
				else
					assert('Image does not exist!!!!!')
				end
			end

			-- check if we have all the test image
			if tc == test_num then 
				break;
			end
		end

		print(lc2, lc1, lc, sc, rc, rc1, rc2);
		print(num_imgs, lc+rc+sc+rc1+lc1+lc2+rc2)

		-- preprocess
		IMGs_test = normalizeyuv(IMGs_test, mean_train, std_train)
		IMGs_test = centralcrop(IMGs_test)
		
		torch.save(data_test_t7, IMGs_test)
		torch.save(label_test_t7, LABELs_test)
		torch.save('./data/pano_v7_traindata_mean_std.t7', {mean_train, std_train})
	end
	return IMGs, LABELs, IMGs_test, LABELs_test
end