-- loaddata.lua
-- require 'image'

function loaddata_full(folderpath)
	local data_t7 = './data/navi_test_160_120_data.t7'
	local label_t7 = './data/navi_test_160_120_label.t7'

	if paths.filep(data_t7) then
		print('Loading data from disc ... ')
		IMGs = torch.load(data_t7)
		LABELs = torch.load(label_t7)
	else 

		local folderpath = folderpath or '/home/lran/data/navigation/000/'

		local names = folderpath .. 'jpgnames.txt'

		local file = io.open(names, 'r')
		local filenames = {}
		for line in file:lines() do
			table.insert(filenames, line)
		end

		local num_imgs = #filenames
		local idx_table = torch.randperm(num_imgs)

		local datasize = num_imgs or 10

		local IMGs = torch.Tensor(datasize, 3, 160, 120)
		local LABELs = torch.zeros(datasize)

		local lc = 0; rc = 0; sc = 0;

		for i = 1, datasize do
			local img_idx = idx_table[i];
			local img_name = filenames[img_idx];

			local img = image.load(img_name);
			img = image.scale(img,160,120)
			img = image.rgb2yuv(img)
			IMGs[i]:copy(img)
			
			-- train data
			if string.find(img_name, 'lc') then
				lc  = lc + 1;
				LABELs[i]= 1;
			elseif string.find(img_name, 'sc') then
				sc = sc +1;
				LABELs[i]= 2;
			elseif string.find(img_name, 'rc') then
				rc = rc + 1;
				LABELs[i]= 3;
			else
				assert('Image does not exist!!!!!')
			end
		end

		print(lc, sc, rc);
		print(num_imgs, lc+rc+sc)
		
		torch.save(data_t7, IMGs)
		torch.save(label_t7, LABELs)
	end

	return IMGs, LABELs
end