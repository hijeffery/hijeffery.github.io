-- centralcrop.lua
-- crop central pixels to remove unexpected noisies.

function centralcrop(imgs, radius)
	local size = imgs:size()
	local ndims = size:size()
	w = size[ndims]
	h = size[ndims - 1]
	cw = math.floor(w/2)
	ch = math.floor(h/2)

	local radius = radius or math.floor(cw/2)
	-- make inner circle:
	mask = torch.ones(w,h)

	local radius2 = radius * radius
	for i = 1,w do
		for j = 1,h do
			local xx = (i-cw)*(i-cw) + (j-ch)*(j-ch)
			if xx <= radius2 then
				mask[{i,j}] = 0
			end
		end
	end

	size[ndims] = 1
	size[ndims - 1] = 1

	local MASK = torch.repeatTensor(mask, size)

	local imgs_msk = torch.cmul(imgs, MASK)

	return imgs_msk
end