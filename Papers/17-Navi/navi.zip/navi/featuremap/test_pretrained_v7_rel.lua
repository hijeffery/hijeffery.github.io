-- test pretrained model, using real sequence data. 

require 'utils/init.lua'

numclasses = arg[1] or 7

local numtest = 3000
local testfolder = '/home/lran/data/navirel'
local testdata_t7 = './data/test_v7_real_data.t7'
local testlabel_t7 = './data/test_v7_real_label.t7'

local imgnames = readtxt(testfolder .. '/front-jpgnames.txt')

print(#imgnames)

numtest = #imgnames
-- load all images
testdata = torch.Tensor(numtest, 3, 101, 101)
-- LABELs = torch.ones(numtest)
Predictions = torch.ones(numtest)

if paths.filep(testdata_t7) then
	testdata = torch.load(testdata_t7)
else
	for i = 1, numtest do
	    xlua.progress(i, numtest)

		local img_name = imgnames[i];

		local img = image.load(img_name);
		img = image.scale(img,101,101)
		img = image.rgb2yuv(img)
		testdata[i]:copy(img)
	end
	torch.save(testdata_t7, testdata)
end

-- local lc = 0; rc = 0; sc = 0; tc = 0; lc1 = 0; rc1 = 0; lc2 =0; rc2 = 0;

-- if paths.filep(testdata_t7) then
-- 	testdata = torch.load(testdata_t7)
-- 	LABELs = torch.load(testlabel_t7)
-- else
-- 	for i = 1, numtest do
-- 	    xlua.progress(i, numtest)

-- 		local img_name = imgnames[i];

-- 		local img = image.load(img_name);
-- 		img = image.scale(img,101,101)
-- 		img = image.rgb2yuv(img)
-- 		testdata[i]:copy(img)
		
-- 		-- train data label
-- 		if string.find(img_name, 'left2') then
-- 			lc1  = lc1 + 1;
-- 			LABELs[i]= 1;
-- 		elseif string.find(img_name, 'left1') then
-- 			lc2  = lc2 + 1;
-- 			LABELs[i]= 2;
-- 		elseif string.find(img_name, 'left') then
-- 			lc = lc +1;
-- 			LABELs[i]= 3;
-- 		elseif string.find(img_name, 'front') then
-- 			sc = sc + 1;
-- 			LABELs[i]= 4;
-- 		elseif string.find(img_name, 'right1') then
-- 			rc1 = rc1 + 1;
-- 			LABELs[i]= 6;
-- 		elseif string.find(img_name, 'right2') then
-- 			rc2 = rc2 + 1;
-- 			LABELs[i]= 7;
-- 		elseif string.find(img_name, 'right') then
-- 			rc = rc + 1;
-- 			LABELs[i]= 5;
-- 		else
-- 			assert('Image does not exist!!!!!')
-- 		end
-- 	end

-- 	print(lc2, lc1, lc, sc, rc, rc1, rc2);
-- 	print(numtest, lc+rc+sc+lc1+rc1+rc2+lc2);	

-- 	-- save files
-- 	torch.save(testdata, testdata_t7)
-- 	torch.save(LABELs, testlabel_t7)
-- end

function testclss( model, data, label)

	local batchsize = 10
	local batches,idxs = makeminibatches(data, batchsize)
	local batchlabel = makeminibatches(label, batchsize, idxs)


	if cuda_enable then
		batches = batches:cuda()
	end

	local numbatches = batches:size(1)
	local confusion = optim.ConfusionMatrix(numclasses)
	confusion:zero()

	local vec_288 = torch.zeros(numbatches, batchsize, 288):cuda()
	local vec_200 = torch.zeros(numbatches, batchsize, 200):cuda()
	local vec_7 = torch.zeros(numbatches, batchsize, 7):cuda()

	for i = 1, numbatches do
		xlua.progress(i, numtest)
		predt = model:forward(batches[i])
		vec_288[i]:copy(model.modules[13].output)
		vec_200[i]:copy(model.modules[15].output)
		vec_7[i]:copy(model.modules[17].output)
		for j = 1, batchsize do
			confusion:add(predt[j], batchlabel[i][j])
		end
	end

	plotheat(vec_288:view(-1, 288), '7class_288')
	plotheat(vec_200:view(-1, 200), '7class_200')
	plotheat(vec_7:view(-1, 7), '7class_7')
	plotheat(confusion.mat, 'cmat')
	print(confusion)
end

MStd = torch.load('./data/pano_v7_traindata_mean_std.t7')
mean_train = MStd[1]
std_train = MStd[2]

testdata = normalizeyuv(testdata, mean_train, std_train)
testdata = centralcrop(testdata)
testdata = testdata:cuda()

-- REPLACE FRONT IMAGES WITH EXPECTED LEFT/RIGHT IMG

-- -- make test sequence for clip 1
-- testdata[{{807,813},{}}] = testdata[{{428,434},{}}]
-- testdata[{{908,924},{}}] = testdata[{{529,545},{}}]
-- testdata[{{1010,1019},{}}] = testdata[{{631,640},{}}]

-- -- make test sequence for clip 2
-- testdata[{{2236,2244},{}}] = testdata[{{5,13},{}}]
-- testdata[{{2352,2365},{}}] = testdata[{{121,134},{}}]
-- testdata[{{2429,2435},{}}] = testdata[{{1313,1319},{}}]
-- testdata[{{2475,2483},{}}] = testdata[{{244,252},{}}]
-- testdata[{{2584,2593},{}}] = testdata[{{1468,1477},{}}]
-- testdata[{{2624,2630},{}}] = testdata[{{393,399},{}}]
-- testdata[{{2697,2706},{}}] = testdata[{{1581,1590},{}}]
-- testdata[{{2797,2806},{}}] = testdata[{{1681,1690},{}}]
-- testdata[{{2865,2875},{}}] = testdata[{{634,644},{}}]
-- testdata[{{2919,2929},{}}] = testdata[{{688,698},{}}]
-- testdata[{{2987,2997},{}}] = testdata[{{1871,1881},{}}]
-- testdata[{{3145,3161},{}}] = testdata[{{914,930},{}}]
-- testdata[{{3271,3280},{}}] = testdata[{{1040,1049},{}}]

-- make test sequence for clip 3
testdata[{{2356,2363},{}}] = testdata[{{109,116},{}}]
testdata[{{2471,2492},{}}] = testdata[{{1347,1368},{}}]
testdata[{{2605,2625},{}}] = testdata[{{1481,1501},{}}]
testdata[{{2699,2705},{}}] = testdata[{{452,458},{}}]
testdata[{{2828,2836},{}}] = testdata[{{581,589},{}}]
testdata[{{2943,2952},{}}] = testdata[{{1819,1828},{}}]
testdata[{{3031,3039},{}}] = testdata[{{1907,1915},{}}]
testdata[{{3310,3316},{}}] = testdata[{{2186,2192},{}}]
testdata[{{3366,3371},{}}] = testdata[{{1119,1124},{}}]

-- -- make test sequence for clip 4
-- testdata[{{1257,1264},{}}] = testdata[{{651,658},{}}]
-- testdata[{{1305,1313},{}}] = testdata[{{94,102},{}}]
-- testdata[{{1361,1369},{}}] = testdata[{{755,763},{}}]
-- testdata[{{1630,1637},{}}] = testdata[{{1024,1031},{}}]

confusion = optim.ConfusionMatrix(numclasses)

model = torch.load('model.net')
model:evaluate()
cuda_enable = true;

sys.tic()
for i = 1, numtest do
	p = model:forward(testdata[{{i}}])
	_, idx = p:max(2)  -- get the max index
	Predictions[i] = idx:float();
end
tc = sys.toc()
print('Avg time consuming ' .. tc/numtest * 1000 .. 'ms.')

mat.save('sequential_predts.mat', Predictions);
-- testclss(model, testdata, LABELs)

gnuplot.plot(Predictions, '-')

::END::