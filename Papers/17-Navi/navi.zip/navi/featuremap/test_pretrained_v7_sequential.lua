-- test_v7 for sequential simulation.lua
require '../utils/init.lua'

numclasses = arg[1] or 7

local testfolder = '/home/lran/data/naviseq/'
local labels = readtxt(testfolder .. 'seqlabels.txt')
local imgnames = readtxt(testfolder .. 'jpgnames.txt')
local numtest = #imgnames
-- local numtest = 10

-- load all images
testdata = torch.Tensor(numtest, 3, 101, 101)
LABELs = torch.ones(numtest)
Predictions = torch.ones(numtest)

for i = 1, numtest do
    xlua.progress(i, numtest)

    LABELs[i] = labels[i];

	local img_name = testfolder .. imgnames[i];

	local img = image.load(img_name);
	img = image.scale(img,101,101)
	img = image.rgb2yuv(img)
	testdata[i]:copy(img)
end

function testclss( model, data, label, predtion)

	local batchsize = 10
	local batches,idxs = makeminibatches(data, batchsize)
	local batchlabel = makeminibatches(label, batchsize, idxs)

	local numbatches = batches:size(1)
	local confusion = optim.ConfusionMatrix(numclasses)
	confusion:zero()

	local vec_288 = torch.zeros(numbatches, batchsize, 288)
	local vec_200 = torch.zeros(numbatches, batchsize, 200)
	local vec_7 = torch.zeros(numbatches, batchsize, 7)

	if cuda_enable then
		batches = batches:cuda()
		vec_288 = vec_288:cuda()
		vec_200 = vec_200:cuda()
		vec_7 = vec_7:cuda()
	end

	for i = 1, numbatches do
		xlua.progress(i, numtest)
		predt = model:forward(batches[i])
		vec_288[i]:copy(model.modules[17].output)
		vec_200[i]:copy(model.modules[19].output)
		vec_7[i]:copy(model.modules[21].output)
		for j = 1, batchsize do
			confusion:add(predt[j], batchlabel[i][j])
		end
	end

	plotheat(vec_288:view(-1, 288), '7class_288')
	plotheat(vec_200:view(-1, 200), '7class_200')
	plotheat(vec_7:view(-1, 7), '7class_7')
	plotheat(confusion.mat, 'cmat')
	print(confusion)
end

testdata = normalizeyuv(testdata)
testdata = centralcrop(testdata)

confusion = optim.ConfusionMatrix(numclasses)

model = torch.load('model.net')
cuda_enable = false;

-- for i = 1, numtest do
-- 	p = model:forward(testdata[{{i}}])
-- 	_, idx = p:max(2)  -- get the max index
-- 	Predictions[i] = idx;
-- end

-- torch.save('sequential_predts.t7', Predictions);
torch.save('sequential_gts.t7', LABELs);
-- testclss(model, testdata, LABELs)

::END::