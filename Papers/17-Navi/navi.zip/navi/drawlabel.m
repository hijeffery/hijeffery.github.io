% draw fig 10 with this script.
% GT control signals and prediction signals.
clear;
close all;

load('sequential_predts.mat');

% % for clip 1:
% y = zeros(379,1);
% y([49:55]) = 1;
% y([150:166]) = 1;
% y([252:261]) = 1;
% x = x([2*379+1:3*379]) - 4;

% % for clip 2:
% y = zeros(1116,1);
% y([5:13]) = -1;
% y([121:134]) = -1;
% y([198:204]) = 1;
% y([244:252]) = -1;
% y([353:362]) = 1;
% y([393:399]) = -1;
% y([466:475]) = 1;
% y([566:575]) = 1;
% y([634:644]) = -1;
% y([688:698]) = -1;
% y([756:766]) = 1;
% y([914:940]) = -1;
% y([1040:1049]) = -1;
% x = x([2*1116+1:3*1116]) - 4;

% % for clip 3:
y = zeros(1124,1);
y([109:116]) = -1;
y([224:245]) = 1;
y([358:378]) = 1;
y([452:458]) = -1;
y([581:589]) = -1;
y([696:705]) = 1;
y([784:792]) = 1;
y([1063:1069]) = 1;
y([1119:1124]) = -1;
x = x([2*1124+1:3*1124]) - 4;

% % for clip 4:
% y = zeros(606,1);
% y([46:53]) = 1;
% y([94:102]) = -1;
% y([150:158]) = 1;
% y([419:426]) = 1;
% x = x([2*606+1:3*606]) - 4;

h1 = figure(1);
plot(y,'g*');
axis([-inf,inf,-4,4]);
legend('Control command');

h2 = figure(2);
plot(x,'r+');
axis([-inf,inf,-4,4]);
legend('Predicted command');

% myboldify(h1);
% myboldify(h2);

print(h1,'clip-g','-dpng'); %将h1保存成figure1.png。
print(h2,'clip-p','-dpng'); %将h1保存成figure1.png。