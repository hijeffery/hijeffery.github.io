srcpath = '/home/lran/data/navigation-homo-frames/USKJ0022';
dstpath = '/home/lran/data/navigation-homo-v7/clip1';

rotate_pano_v7(srcpath, dstpath);

srcpath = '/home/lran/data/navigation-homo-frames/USKJ0050';
dstpath = '/home/lran/data/navigation-homo-v7/clip2';

rotate_pano_v7(srcpath, dstpath);

srcpath = '/home/lran/data/navigation-homo-frames/USKJ0052';
dstpath = '/home/lran/data/navigation-homo-v7/clip3';

rotate_pano_v7(srcpath, dstpath);

srcpath = '/home/lran/data/navigation-homo-frames/USKJ0053';
dstpath = '/home/lran/data/navigation-homo-v7/clip4';

rotate_pano_v7(srcpath, dstpath);
