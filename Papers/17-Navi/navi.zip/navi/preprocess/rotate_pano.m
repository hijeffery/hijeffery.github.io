% rotate pano images to gen 3 directions.

prefixpath = '/home/lran/Desktop/tmp/';
filenames = dir([prefixpath '/*.png']);
% imgsize:1200x1600x3

num_imgs = size(filenames,1);

num_directions = 5;
rotate_degree = 180/num_directions;

mkdir([prefixpath 'front'])
mkdir([prefixpath 'left'])
mkdir([prefixpath 'right'])
mkdir([prefixpath 'left1'])
mkdir([prefixpath 'right1'])

% parpool(4)

parfor i = 1:num_imgs
	img = imread([prefixpath  filenames(i).name]);
	
	% img = imread('C:\\Users\\ran\\Desktop\\data/USKJ0023.jpg');
	img = double(img);

	% front
	% img1 = img(:,500:4000,:);
	img1 = img(:,190:1400,:);
	% figure('Name', 'Front', 'NumberTitle', 'off');
	% imshow(img1/255);
	imwrite(img1/255, [prefixpath 'front/' filenames(i).name]);

	% Need to turn right:
	img2 = imrotate(img,rotate_degree);
	% img2 = img2(1100:4600, 900:4400, :);
	img2 = img2(400:1600, 320:1530, :);

	% figure('Name', 'Turn right', 'NumberTitle', 'off');
	% imshow(img2/255);
	imwrite(img2/255, [prefixpath 'right/' filenames(i).name]);

	% Need to turn LEFT:
	img3 = imrotate(img, -rotate_degree);
	img3 = img3(400:1600, 320:1530, :);
	% img3 = img3(1100:4600, 900:4400,:);

	% figure('Name', 'Turn left', 'NumberTitle', 'off');
	% imshow(img3/255);
	imwrite(img3/255, [prefixpath 'left/' filenames(i).name]);

	% right1
	img4 = imrotate(img,rotate_degree*2);
	img4 = img4(400:1600, 320:1530, :);
	imwrite(img4/255, [prefixpath 'right1/' filenames(i).name]);

	% left1
	img5 = imrotate(img,-2*rotate_degree);
	img5 = img5(400:1600, 320:1530, :);
	imwrite(img5/255, [prefixpath 'left1/' filenames(i).name]);
end