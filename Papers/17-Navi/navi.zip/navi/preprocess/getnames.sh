#!/bin/bash 

# cd to dataset folder. Then:
# getnames.sh
folder='pwd';
find $folder -name *.jpg > names.txt