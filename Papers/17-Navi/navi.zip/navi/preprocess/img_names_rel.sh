#!/bin/bash 


# getnames.sh
folder=`pwd`
folder="$folder/clip3"
find $folder -name *.png > front-jpgnames.txt