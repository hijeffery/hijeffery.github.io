% rotate pano images to gen 7 directions.
%% rotate_pano_v7: function description
function rotate_pano_v7(srcpath, dstpath)

% prefixpath = '/home/lran/Desktop/tmp4/';
filenames = dir([srcpath '/*.png']);
% imgsize:1200x1600x3

num_imgs = size(filenames,1);

num_directions = 7;
rotate_degree = [-(90 - 12.5), -(65 - 12.5), -(40-12.5), 0, (40-12.5), (65-12.5), (90-12.5)];

mkdir([dstpath '/front'])
mkdir([dstpath '/left'])
mkdir([dstpath '/right'])
mkdir([dstpath '/left1'])
mkdir([dstpath '/right1'])
mkdir([dstpath '/left2'])
mkdir([dstpath '/right2'])

% generate circle mask:
cx=800;cy=600; % circle center
ix=1600;iy=1200; % image size
r=600; % radius
[x,y]=meshgrid(-(cx-1):(ix-cx),-(cy-1):(iy-cy)); % points 
c_mask=((x.^2+y.^2)<=r^2); % mask
c_masks = repmat(c_mask, 1,1,3); % image mask
c_masks = double(c_masks);

myparpool = parpool(4);

parfor i = 1:num_imgs
	img = imread([srcpath '/' filenames(i).name]);
	img = double(img)/255;

	% front
	img1 = img.*c_masks;
	img1 = img1(:,200:1400,:);
	imwrite(img1, [dstpath '/front/' filenames(i).name]);

	% Need to turn right:
	img2 = imrotate(img, rotate_degree(5), 'crop');
	img2 = img2.*c_masks;
	img2 = img2(:,200:1400,:);
	imwrite(img2, [dstpath '/right/' filenames(i).name]);

	% right1
	img3 = imrotate(img, rotate_degree(6), 'crop');
	img3 = img3.*c_masks;
	img3 = img3(:,200:1400,:);
	imwrite(img3, [dstpath '/right1/' filenames(i).name]);

	% right2
	img4 = imrotate(img, rotate_degree(7), 'crop');
	img4 = img4.*c_masks;
	img4 = img4(:,200:1400,:);
	imwrite(img4, [dstpath '/right2/' filenames(i).name]);

	% Need to turn LEFT:
	img5 = imrotate(img, rotate_degree(3), 'crop');
	img5 = img5.*c_masks;
	img5 = img5(:,200:1400,:);
	imwrite(img5, [dstpath '/left/' filenames(i).name]);

	% left1
	img6 = imrotate(img, rotate_degree(2), 'crop');
	img6 = img6.*c_masks;
	img6 = img6(:,200:1400,:);
	imwrite(img6, [dstpath '/left1/' filenames(i).name]);

	% left2
	img7 = imrotate(img, rotate_degree(1), 'crop');
	img7 = img7.*c_masks;
	img7 = img7(:,200:1400,:);
	imwrite(img7, [dstpath '/left2/' filenames(i).name]);
end

delete(myparpool);

end