#! /bin/bash
# video2frame_vlc.sh

mkdir ~/Desktop/tmp1
cvlc --video-filter scene --scene-ratio 30 --scene-prefix image --scene-path ~/Desktop/tmp1 ~/data/navigation-homo/clip1/USKJ0022.MP4 
mkdir ~/Desktop/tmp2
cvlc --video-filter scene --scene-ratio 30 --scene-prefix image --scene-path ~/Desktop/tmp2 ~/data/navigation-homo/clip2/USKJ0050.MP4 
mkdir ~/Desktop/tmp3
cvlc --video-filter scene --scene-ratio 30 --scene-prefix image --scene-path ~/Desktop/tmp3 ~/data/navigation-homo/clip3/USKJ0052.MP4 
mkdir ~/Desktop/tmp4
cvlc --video-filter scene --scene-ratio 30 --scene-prefix image --scene-path ~/Desktop/tmp4 ~/data/navigation-homo/clip4/USKJ0053.MP4 