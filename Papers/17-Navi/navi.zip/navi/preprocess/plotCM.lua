-- plot Confusion Matrix with gnuplot

require 'gnuplot'
require 'hdf5'

local file = hdf5.open('cm7.h5', 'r')
cm = file:read('/data'):all()
file:close()

gnuplot.imagesc(cm,'color')

gnuplot.raw('set xtics ("Left3" 0, "Left2" 1, "Left1" 2, "Front" 3, "Right1" 4, "Right2" 5, "Right3" 6)')
gnuplot.raw('set ytics ("Left3" 0, "Left2" 1, "Left1" 2, "Front" 3, "Right1" 4, "Right2" 5, "Right3" 6)')
gnuplot.raw('set view map')
gnuplot.raw('splot cm matrix with image')

gnuplot.plotflush()