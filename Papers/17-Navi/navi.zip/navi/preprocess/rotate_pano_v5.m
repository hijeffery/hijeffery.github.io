% rotate pano images to gen 5 directions.

prefixpath = '/home/lran/Desktop/tmp4/';
filenames = dir([prefixpath '/*.png']);
% imgsize:1200x1600x3

num_imgs = size(filenames,1);

num_directions = 5;
rotate_degree = 180/num_directions;

mkdir([prefixpath 'front'])
mkdir([prefixpath 'left'])
mkdir([prefixpath 'right'])
mkdir([prefixpath 'left1'])
mkdir([prefixpath 'right1'])

% generate circle mask:
cx=800;cy=600; % circle center
ix=1600;iy=1200; % image size
r=600; % radius
[x,y]=meshgrid(-(cx-1):(ix-cx),-(cy-1):(iy-cy)); % points 
c_mask=((x.^2+y.^2)<=r^2); % mask
c_masks = repmat(c_mask, 1,1,3); % image mask
c_masks = double(c_masks);

myparpool = parpool(4);

parfor i = 1:num_imgs
	img = imread([prefixpath  filenames(i).name]);
	img = double(img)/255;

	% front
	img1 = img.*c_masks;
	img1 = img1(:,200:1400,:);
	imwrite(img1, [prefixpath 'front/' filenames(i).name]);

	% Need to turn right:
	img2 = imrotate(img, rotate_degree, 'crop');
	img2 = img2.*c_masks;
	img2 = img2(:,200:1400,:);
	imwrite(img2, [prefixpath 'right/' filenames(i).name]);

	% right1
	img3 = imrotate(img, rotate_degree*2, 'crop');
	img3 = img3.*c_masks;
	img3 = img3(:,200:1400,:);
	imwrite(img3, [prefixpath 'right1/' filenames(i).name]);

	% Need to turn LEFT:
	img4 = imrotate(img, -rotate_degree, 'crop');
	img4 = img4.*c_masks;
	img4 = img4(:,200:1400,:);
	imwrite(img4, [prefixpath 'left/' filenames(i).name]);

	% left1
	img5 = imrotate(img, -2*rotate_degree, 'crop');
	img5 = img5.*c_masks;
	img5 = img5(:,200:1400,:);
	imwrite(img5, [prefixpath 'left1/' filenames(i).name]);
end

delete(myparpool);
