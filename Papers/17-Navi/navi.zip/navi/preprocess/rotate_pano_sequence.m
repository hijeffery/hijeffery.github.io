% rotate pano images to gen a series of directions. This is for the navigation simulation experiment.
% suitable for the v7 case.
% default test seq is clip3
%% rotate_pano_sequence: function description
function rotate_pano_sequence()

srcpath = '/home/lran/data/navigation-homo-v7/';
dstpath = '/home/lran/data/navigation-homo-v7/naviseq/';

% imgsize:1201x1200x3
filenames = dir([srcpath 'clip3/front/*.png']);

num_imgs = size(filenames,1);

labels = zeros(num_imgs,1);

mkdir(dstpath);

% generate circle mask:
cx=600;cy=600; % circle center
ix=1201;iy=1200; % image size
r=600; % radius
[x,y]=meshgrid(-(cx-1):(ix-cx),-(cy-1):(iy-cy)); % points 
c_mask=((x.^2+y.^2)<=r^2); % mask
c_masks = repmat(c_mask, 1,1,3); % image mask
c_masks = double(c_masks);

myparpool = parpool(4);

rotate_degree = [-(90 - 12.5), -(65 - 12.5), -(40-12.5), 0, (40-12.5), (65-12.5), (90-12.5)];

for i = 1:num_imgs
	img = imread([srcpath 'clip3/front/' filenames(i).name]);
	img = double(img)/255;

	% frame to angle:
	f2ang = i/1000*2*3.14;
	ang = sin(f2ang) * 85;  % less than 85(90) degree.

	img2 = imrotate(img, ang, 'crop');
	img2 = img2.*c_masks;
	imwrite(img2, [dstpath filenames(i).name]);	

	% save label
	if ang > 65 
		labels(i) = 7;
	elseif ang > 40 
		labels(i) = 6;
	elseif ang > 15 
		labels(i) = 5;
	elseif ang > -15 
		labels(i) = 4;
	elseif ang > -40 
		labels(i) = 3;
	elseif ang > -65 
		labels(i) = 2;
	else
		labels(i) = 1;
	end
end

delete(myparpool);

%Images are presaved. Labels need to save before exit. 
fid = fopen([dstpath 'seqlabels.txt'], 'w');
fprintf(fid, '%d\n', labels);
fclose(fid);
end