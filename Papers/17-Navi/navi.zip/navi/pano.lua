-- pano.lua
-- train on the pano image. without unwarping or cropping

require './utils/init.lua'
PFi = require 'utils/ProFi'

-- ================ Cmd Line  =======================
cmd = torch.CmdLine()
cmd:text()
cmd:text()
cmd:text('Training on PANO dataset with Conv_net:')
cmd:text()
cmd:text('Options')
cmd:option('-trsz', 	100, 		'Training data size.')
cmd:option('-fltsz', 	3, 			'filtersize for convolutional layers')
cmd:option('-svdir', 	'result', 	'subdirectory to save experiments in')
cmd:option('-model', 	0, 			'1: contour, 2: contour_bottle, 3: bottle with differ codes; 4 bottle with nin')
cmd:option('-init', 	0, 			'0: me, 1: others')
cmd:option('-cuda', 	0, 			'0: disable, 1: enable')

-- training
cmd:option('-piter',	20,			'Pretrain iteration, for RBM init.')
cmd:option('-maxiter', 	100, 		'Max epoch of the BP part')
cmd:option('-lr', 	1e-3, 		'learning rate')
cmd:option('-weightDecay', 	0, 		'weight Decay')
cmd:option('-momentum', 	0, 		'momentum for sgd methods.')
cmd:option('-train',	1,			'Training module, 1: trainCNN, 2 train with beta=0; ')
cmd:option('-adjlr',	0,			'Adjust learning rate. ')
cmd:option('-optmsd',	2,			'Optimization methods, 1 SGD, 2 adagrad')


-- data
cmd:option('-data', 	1,			'data: 1 horse, 2 semantic contour')
cmd:option('-color', 	0,			'gray 0; color: 1')
cmd:option('-inputsize', 40, 		'size of each input patch')
cmd:option('-batchsize', 1,     'batchsize')
cmd:option('-testfolder', 'clip3')
cmd:option('-numclasses',  3)
cmd:option('-imgful',  0)

-- criterion
cmd:option('-alpha',	1, 			'reconstruction error')
cmd:option('-beta',  	0, 			'template error')

cmd:text()

-- parse input params
params         = cmd:parse(arg)
params.maindir = paths.cwd()

local scriptname = 'pano_navi'
local rundir     = cmd:string(scriptname, params, {lrate=true})
params.rundir    = params.svdir.. '/' .. rundir

if path_exists(params.rundir) then
   os.execute('rm -r ' .. params.rundir)
end
os.execute('mkdir -p ' .. params.rundir)
cmd:addTime(scriptname)
cmd:log(params.rundir .. '/log.txt', params)

params.trainLoss = torch.zeros(params.maxiter)
params.trainDw   = torch.zeros(params.maxiter)
params.trainw    = torch.zeros(params.maxiter)
if params.cuda == 1 then
	cuda_enable = true
end

logger = optim.Logger(params.rundir .. '/trainerrors.txt')
logger:setNames{'Training Error'}

-- =============== END CMD LINE ============================================
PFi:start()
starttime = sys.clock()

img_full = params.imgful

if params.numclasses == 3 then
  dataset, label, testdata, testlabel = loadPano_train_test(params.trsz, params.testfolder)
elseif params.numclasses == 5 then
  dataset, label, testdata, testlabel = loadPano_v5(params.trsz, params.testfolder)
elseif params.numclasses == 7 then
  dataset, label, testdata, testlabel = loadPano_v7(params.trsz, params.testfolder)
else
  print('Wrong class number ...')
  goto END  
end

print('load model')

local filter_size = 5
local pad_size = 2

if params.model == 0 then
  model = loadmodel0()
elseif params.model ==1 then
  model = loadmodel1()  
elseif params.model ==2 then
  model = loadmodel2()  
elseif params.model ==3 then
  model = loadmodel3()  
elseif params.model ==4 then
  model = loadmodel4()  
else
  assert('Model need to be defined.')
end

confusion = optim.ConfusionMatrix(params.numclasses)

criterion = nn.ClassNLLCriterion()


-- if cuda_enable then
--   model = model:cuda()
--   criterion = criterion:cuda()
--   -- dataset = dataset:cuda()
-- end

if not sgd_params then
	sgd_params = {
     learningRate      = params.lr,
     learningRateDecay = 1e-4,
     weightDecay       = params.weightDecay,
     momentum          = params.momentum,
     evalCounter       = params.evalCounter
	}
end

local trsize = dataset:size(1)

w,dl_dw = model:getParameters()

function train()

   -- epoch tracker
   epoch = epoch or 1

   confusion:zero()

   -- local vars
   local time = sys.clock()

   -- set model to training mode (for modules that differ in training and testing, like Dropout)
   model:training()

   -- shuffle at each epoch
   shuffle = torch.randperm(trsize)
   -- print(shuffle)

   -- do one epoch
   print("==> online epoch # " .. epoch .. ' [batchSize = ' .. params.batchsize .. ']')
      local loss_batches = 0
   for t = 1, trsize, params.batchsize do
      -- disp progress
      xlua.progress(t, dataset:size(1))
      -- create mini batch
      local inputs = {}
      local targets = {}
      for i = t, math.min(t+params.batchsize-1, trsize) do
         -- load new sample
         local input = dataset[shuffle[i]]
         local target = label[shuffle[i]]

         if params.type == 'double' then input = input:double()
         elseif cuda_enable then input = input:cuda() end
         table.insert(inputs, input)
         table.insert(targets, target)
      end

      -- create closure to evaluate f(X) and df/dX
      local feval = function(x)
                       -- get new parameters
                       if x ~= w then
                          w:copy(x)
                       end

                       -- reset gradients
                       dl_dw:zero()

                       -- f is the average of all criterions
                       local f = 0

                       -- evaluate function for complete mini batch
                       for i = 1,#inputs do
                          -- estimate f
                          local output = model:forward(inputs[i])

                          local err = criterion:forward(output, targets[i])
                          
                          f = f + err

                          -- estimate df/dW
                          local df_do = criterion:backward(output, targets[i])
                          model:backward(inputs[i], df_do)

                          -- update confusion
                          confusion:add(output, targets[i])
                       end

                       -- normalize gradients and f(X)
                       dl_dw:div(#inputs)
                       f = f/#inputs

                       -- print(dl_dw:sum())
                       -- return f and df/dX
                       return f, dl_dw
                    end

      -- optimize on current mini-batch
      _,fs = optim.sgd(feval,w,sgd_params)
      -- if optimMethod == optim.asgd then
      --    _,_,average = optimMethod(feval, parameters, optimState)
      -- else
      --    optimMethod(feval, parameters, optimState)
      -- end
      loss_batches = loss_batches + fs[1]
   end

   -- time taken
   time = sys.clock() - time
   time = time / trsize
   print("\n==> time to learn 1 sample = " .. (time*1000) .. 'ms')

   -- print confusion matrix
   print(confusion)

   -- update logger/plot
   -- trainLogger:add{['% mean class accuracy (train set)'] = confusion.totalValid * 100}
   -- if params.plot then
   --    trainLogger:style{['% mean class accuracy (train set)'] = '-'}
   --    trainLogger:plot()
   -- end

   -- -- save/log current net
   -- local filename = paths.concat(params.save, 'model.net')
   -- os.execute('mkdir -p ' .. sys.dirname(filename))
   -- print('==> saving model to '..filename)
   -- torch.save(filename, model)

   -- next epoch
   epoch = epoch + 1

   print(loss_batches)
end


-- test function
function test()
   -- local vars
   local time = sys.clock()

   -- next iteration:
   confusion:zero()

   -- averaged param use?
   if average then
      cachedparams = parameters:clone()
      parameters:copy(average)
   end

   -- set model to evaluate mode (for modules that differ in training and testing, like Dropout)
   model:evaluate()

   -- test over test data
   print('==> testing on test set:')
   for t = 1,testData:size() do
      -- disp progress
      xlua.progress(t, testData:size())

      -- get new sample
      local input = testData.data[t]
      if params.type == 'double' then input = input:double()
      elseif cuda_enable then input = input:cuda() end
      
      local target = testData.labels[t]

      -- test sample
      local pred = model:forward(input)
      confusion:add(pred, target)

   end

   -- timing
   time = sys.clock() - time
   time = time / testData:size()
   print("\n==> time to test 1 sample = " .. (time*1000) .. 'ms')

   -- print confusion matrix
   print(confusion)

   -- update log/plot
   -- testLogger:add{['% mean class accuracy (test set)'] = confusion.totalValid * 100}
   
   if params.plot then
      testLogger:style{['% mean class accuracy (test set)'] = '-'}
      testLogger:plot()
   end

   -- averaged param use?
   if average then
      -- restore parameters
      parameters:copy(cachedparams)
   end
   
end

-- local tesize = testdata:size(1) 

-- testData = {
--    data = testdata,
--    labels = testlabel,
--    size = function() return tesize end
-- }


-- local test_precision_old = 0

-- for i = 1, params.maxiter do
--   train()
--   print(confusion.totalValid)

--   -- Early stopping:
--   if confusion.totalValid > 0.9 then
--     -- begin check test error rate
--     test()
--     torch.save(params.rundir .. '/model.net', model)
--     -- if test_precision_old > confusion.totalValid then
--     --   print('Early stopping ... ')
--     --   break
--     -- else
--     --   test_precision_old = confusion.totalValid
--     -- end
--   end

--   -- adjust lr
--   if i == 100 then 
--     sgd_params.learningRate = sgd_params.learningRate/10
--   end
-- end

-- pred = model:forward(dataset)
-- loss = criterion:forward(pred, label)
-- grad = criterion:backward(pred, label)
-- model:backward(dataset, grad)

traincnn(model, dataset, label, criterion ,sgd_params)

print('Train confusion matrix:')
testcls(model, dataset, label)
testcls(model, testdata, testlabel)

print('Time consuming ' .. sys.clock() - starttime .. 's.')
torch.save(params.rundir .. '/model.net', model)

logger:style{'-'}
logger:plot()

PFi:stop()
PFi:writeReport(params.rundir .. '/ProFi_report.txt')

::END::