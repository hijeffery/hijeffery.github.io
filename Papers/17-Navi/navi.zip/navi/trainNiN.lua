require './utils/init.lua'

-- ================ Cmd Line  =======================
cmd = torch.CmdLine()
cmd:text()
cmd:text()
cmd:text('Training on PANO dataset with Conv_net:')
cmd:text()
cmd:text('Options')
cmd:option('-trsz', 	100, 		'Training data size.')
cmd:option('-fltsz', 	3, 			'filtersize for convolutional layers')
cmd:option('-svdir', 	'result', 	'subdirectory to save experiments in')
cmd:option('-model', 	4, 			'1: contour, 2: contour_bottle, 3: bottle with differ codes; 4 prewarp with nin')
cmd:option('-init', 	0, 			'0: me, 1: others')
cmd:option('-cuda', 	1, 			'0: disable, 1: enable')

-- training
cmd:option('-piter',	20,			'Pretrain iteration, for RBM init.')
cmd:option('-maxiter', 	100, 		'Max epoch of the BP part')
cmd:option('-lr', 	1e-5, 		'learning rate')
cmd:option('-weightDecay', 	0, 		'weight Decay')
cmd:option('-momentum', 	0, 		'momentum for sgd methods.')
cmd:option('-train',	1,			'Training module, 1: trainCNN, 2 train with beta=0; ')
cmd:option('-adjlr',	0,			'Adjust learning rate. ')
cmd:option('-optmsd',	2,			'Optimization methods, 1 SGD, 2 adagrad')


-- data
cmd:option('-data', 	1,			'data: 1 horse, 2 semantic contour')
cmd:option('-color', 	0,			'gray 0; color: 1')
cmd:option('-inputsize', 40, 		'size of each input patch')
cmd:option('-batchsize', 10,     'batchsize')
cmd:option('-testfolder', 'clip3')
cmd:option('-numclasses',  7)

-- criterion
cmd:option('-alpha',	1, 			'reconstruction error')
cmd:option('-beta',  	0, 			'template error')

cmd:text()

-- parse input params
params = cmd:parse(arg)
params.maindir = paths.cwd()

local scriptname = 'NiN'
local rundir = cmd:string(scriptname, params, {lrate=true})
params.rundir = params.svdir.. '/' .. rundir

if path_exists(params.rundir) then
   os.execute('rm -r ' .. params.rundir)
end
os.execute('mkdir -p ' .. params.rundir)
cmd:addTime(scriptname)
cmd:log(params.rundir .. '/log.txt', params)

params.trainLoss = torch.zeros(params.maxiter)
params.trainDw = torch.zeros(params.maxiter)
params.trainw = torch.zeros(params.maxiter)
if params.cuda == 1 then
	cuda_enable = true
end
-- =============== END CMD LINE ============================================
starttime = sys.clock()

local outputsize = 1000
model = loadmodel5()
model:remove(#model.modules)
model:add(nn.ReLU())
model:add(nn.Reshape(outputsize*1*1))
model:add(nn.Linear(outputsize*1*1, 200))
model:add(nn.ReLU())

model:add(nn.Linear(200, 7))
model:add(nn.ReLU())

model:add(nn.LogSoftMax())

-- Suppose numclasses == 7
imgsize = {10,3,224,224}
dataset, label, testdata, testlabel = loadPano_v7(params.trsz, params.testfolder, imgsize[3], imgsize[4])

-- train
criterion = nn.ClassNLLCriterion()
confusion = optim.ConfusionMatrix(params.numclasses)
if not sgd_params then
	sgd_params = {
	   learningRate = params.lr,
	   learningRateDecay = 1e-4,
	   weightDecay = params.weightDecay,
	   momentum = params.momentum,
	   evalCounter = params.evalCounter
	}
end
w,dl_dw = model:getParameters()

model_t = traincnn(model, dataset, label, criterion)

testcls(model_t, dataset, label)
testcls(model_t, testdata, testlabel)