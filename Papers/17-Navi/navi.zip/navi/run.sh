#! /bin/bash

# benchmark: train 86.1, test 63.2
# th pano.lua -trsz 2000 -maxiter 3000 -cuda 1 -batchsize 1 -lr 1e-4

# change model0 to PReLU, add normalize: train 93.8%, test 88.17%
# th pano.lua -trsz 3000 -maxiter 300 -cuda 1 -batchsize 1 -lr 1e-4

# central zero and train: 93.1% test 88.67%
# th pano.lua -trsz 3000 -maxiter 200 -cuda 1 -batchsize 1 -lr 1e-4

# normalize image ,y local u v global; train: 91.51% test: 88.95%
# th pano.lua -trsz 3000 -maxiter 150 -cuda 1 -batchsize 1 -lr 1e-4

# normalize image, using same mean and std for train and test. train 92.97%, test 87.61%
# better normalize train and test seperately, for they may be captured in different imullision condition
# th pano.lua -trsz 3000 -maxiter 140 -cuda 1 -batchsize 1 -lr 1e-4

# batch normalization: train:97.96% test 94.30%
# th pano.lua -trsz 3000 -maxiter 1000 -cuda 0 -batchsize 10 -lr 1e-4 -model 1

# >> crop image with a circle. 2015.03.19 <<   
# 5 classes: train: 100% test 84.8%
# th -i pano.lua -trsz 6000 -maxiter 3000 -cuda 1 -batchsize 10 -lr 1e-3 -model 0 -numclasses 5

# 5 classes: train:100 % test 93.07%
# th -i pano.lua -trsz 6000 -maxiter 1000 -cuda 0 -batchsize 10 -lr 1e-3 -model 1 -numclasses 5

# 7 classes: train 100%, teat 86.41%;
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 0 -batchsize 10 -lr 1e-3 -model 1 -numclasses 7

#================= run comparision experiments ========================
# 3 class Tanh
# th pano.lua -trsz 3000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 3 -numclasses 3 #95.58%
# 3 class ReLU
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 2 -numclasses 3
# 3 class PReLU
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 0 -numclasses 3
# 3 class BN:
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 0 -batchsize 10 -lr 1e-3 -model 1 -numclasses 7

# 5 class Tanh
# th pano.lua -trsz 3000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 3 -numclasses 5 #87%
# 5 class ReLU
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 2 -numclasses 5
# 5 class PReLU
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 0 -numclasses 5
# 5 class BN:
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 0 -batchsize 10 -lr 1e-3 -model 1 -numclasses 3

# 7 class Tanh
# th pano.lua -trsz 3000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 3 -numclasses 7 #80% 77.3%
# 7 class ReLU
# th pano.lua -trsz 3000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 2 -numclasses 7 #72.96%
# 7 class PReLU
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 0 -numclasses 7
# 7 class BN:
# th pano.lua -trsz 6000 -maxiter 1000 -cuda 0 -batchsize 10 -lr 1e-3 -model 1 -numclasses 7

# ====================== 2016.10 ======================================
# check spatialcontrastnorm: w / wt
# model0/model1 and model2 two mode shows SCN not good.
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 0 -numclasses 7  #w 78.28
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 1 -numclasses 7  #wt 75.91
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 2 -numclasses 7  #70.24/74.79
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 3 -numclasses 7  #73.21
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 7  #86.18/86.18 w/wrt SCN seems the same.

# ====================== 2016.11.02 ======================================
#
# remeber to delete navi/data/* files before run each experiment
#
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 7  #86.18/86.18 w/wrt SCN seems the same.
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 7 -imgful 1 #66.01%
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 7 -imgful 2 #86.81%

# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 5  # 96.58%
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 5 -imgful 1 #81.59%
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 5 -imgful 2 #98.68%

# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 3  #98.94%
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 3 -imgful 1 #95.68%
# th pano.lua -trsz 2000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 3 -imgful 2 #99.76%


# ====================== 2016.11.11 ======================================
#
# remeber to delete navi/data/* files before run each experiment
#
# 
rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 7  #86.18/86.18 w/wrt SCN seems the same.
# 
rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 7 -imgful 1 #66.01%
# 
rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 7 -imgful 2 #86.81%

#
rm data/*

rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 5  # 96.58%
# 
rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 5 -imgful 1 #81.59%
# 
rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 5 -imgful 2 #98.68%

#
rm data/*

rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 3  #98.94%
# 
rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 3 -imgful 1 #95.68%
# 
rm data/*
th pano.lua -trsz 6000 -maxiter 1000 -cuda 1 -batchsize 10 -lr 1e-3 -model 4 -numclasses 3 -imgful 2 #99.76%

###################################################################
# TODO: add comparision
# 1. SVM on alexnet features
# 2. SVM on multipart features
# 3. SVM on autoencoder features
# -4. multi-class classification
# -5. make a circle mask. 