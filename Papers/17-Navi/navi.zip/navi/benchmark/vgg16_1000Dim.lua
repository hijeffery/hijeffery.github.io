-- extract image into features, 1000 Dim.
-- using pretrained model
-- input: 10x3x224x224 batch data

require 'utils/init.lua'

-- load train and test data
local trainsize = 3000 
local testfolder = 'clip3';
dataset, label, testdata, testlabel = loadPano_train_test(trainsize, testfolder, 224, 224)

dataset, mean_train, std_train = normalizeyuv(dataset)
-- testdata = normalizeyuv(testdata, mean_train, std_train)
testdata = normalizeyuv(testdata)

model = loadcaffe.load('../model/VGG_ILSVRC_16_layers_deploy.prototxt', 'model/VGG_ILSVRC_16_layers.caffemodel', 'cudnn')

batchtrain = makeminibatches(dataset,10)
batchtest = makeminibatches(testdata,10)

print(batchtrain:size())

local num_batches = batchtrain:size(1)
vectrain = torch.Tensor(num_batches, 10, 1000)


for i = 1, num_batches do
	vectrain[i]:copy( model:forward(batchtrain[i]:cuda()))
end

local num_testbatches = batchtest:size(1)
vectest = torch.Tensor(num_testbatches, 10, 1000)
for i = 1, num_testbatches do
	vectest[i]:copy(model:forward(batchtest[i]:cuda()))
end

svmwrite('../result/train.dat', vectrain, label)
svmwrite('../result/test.dat', vectest, testlabel)