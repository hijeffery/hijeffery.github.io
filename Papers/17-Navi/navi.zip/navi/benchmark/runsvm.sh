#! /bin/bash

/home/lran/Software/svm/svm_multiclass_learn -c 1000.0 -t 3 ../data/train.dat model

/home/lran/Software/svm/svm_multiclass_classify ../data/test.dat model predictions
