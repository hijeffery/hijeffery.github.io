require './utils/init.lua'

-- ================ Cmd Line  =======================
cmd = torch.CmdLine()
cmd:text()
cmd:text()
cmd:text('Training on PANO dataset with Conv_net:')
cmd:text()
cmd:text('Options')
cmd:option('-trsz', 	100, 		'Training data size.')
cmd:option('-fltsz', 	3, 			'filtersize for convolutional layers')
cmd:option('-svdir', 	'result', 	'subdirectory to save experiments in')
cmd:option('-model', 	4, 			'1: contour, 2: contour_bottle, 3: bottle with differ codes; 4 prewarp with nin')
cmd:option('-init', 	0, 			'0: me, 1: others')
cmd:option('-cuda', 	0, 			'0: disable, 1: enable')

-- training
cmd:option('-piter',	20,			'Pretrain iteration, for RBM init.')
cmd:option('-maxiter', 	100, 		'Max epoch of the BP part')
cmd:option('-lr', 	1e-5, 		'learning rate')
cmd:option('-weightDecay', 	0, 		'weight Decay')
cmd:option('-momentum', 	0, 		'momentum for sgd methods.')
cmd:option('-train',	1,			'Training module, 1: trainCNN, 2 train with beta=0; ')
cmd:option('-adjlr',	0,			'Adjust learning rate. ')
cmd:option('-optmsd',	2,			'Optimization methods, 1 SGD, 2 adagrad')

-- data
cmd:option('-data', 	1,			'data: 1 horse, 2 semantic contour')
cmd:option('-color', 	0,			'gray 0; color: 1')
cmd:option('-inputsize', 40, 		'size of each input patch')
cmd:option('-batchsize', 10,     'batchsize')
cmd:option('-testfolder', 'clip3')
cmd:option('-numclasses',  7)

-- criterion
cmd:option('-alpha',	1, 			'reconstruction error')
cmd:option('-beta',  	0, 			'template error')

cmd:text()

-- parse input params
params = cmd:parse(arg)
params.maindir = paths.cwd()

local scriptname = 'DfNets'
local rundir = cmd:string(scriptname, params, {lrate=true})
params.rundir = params.svdir.. '/' .. rundir

if path_exists(params.rundir) then
   os.execute('rm -r ' .. params.rundir)
end
os.execute('mkdir -p ' .. params.rundir)
cmd:addTime(scriptname)
cmd:log(params.rundir .. '/log.txt', params)

params.trainLoss = torch.zeros(params.maxiter)
params.trainDw = torch.zeros(params.maxiter)
params.trainw = torch.zeros(params.maxiter)
if params.cuda == 1 then
	cuda_enable = true
end
-- =============== END CMD LINE ============================================
starttime = sys.clock()

-- prepare data
if params.model == 4 then 
	-- model NiN
	imgsize = {10,3,224,224}
	model_p = loadmodel4()

	-- remove the 1024->1000 layer.
	model_p:remove(#model_p.modules-2)
	model_p:remove(#model_p.modules-2)

	-- remove the 1024->1024 layer.
	model_p:remove(#model_p.modules-2)
	model_p:remove(#model_p.modules-2)

	-- remove SoftMax
	model_p:remove(#model_p.modules)

end

if params.model == 5 then 
	-- model VGG
	imgsize = {10,3,224,224}
	model = loadmodel4()

	-- remove the 1024->1000 layer.
	model:remove(#model.modules-2)
	model:remove(#model.modules-2)

	-- remove the 1024->1024 layer.
	model:remove(#model.modules-2)
	model:remove(#model.modules-2)
end

-- Suppose numclasses == 7
dataset, label, testdata, testlabel = loadPano_v7(params.trsz, params.testfolder, imgsize[3], imgsize[4])

-- $$$ Step 1: warp image with pretrained model
print('Warpping images with pretrained model ... ')
batchsize = imgsize[1];
dataset, idx = makeminibatches(dataset, batchsize)
label = makeminibatches(label, batchsize, idx)

testdata, idx = makeminibatches(testdata, batchsize)
testlabel = makeminibatches(testlabel, batchsize, idx)

-- model NiN output: 10*1024*1*1
local outputsize = 1024
data_vecs = torch.zeros(dataset:size(1), batchsize, outputsize,1,1)
-- goto theVeryEnd
for i = 1, data_vecs:size(1) do
	data_vecs[i]:copy(model_p:forward(dataset[i]))
end

data_vecs = data_vecs:view(-1, outputsize, 1,1)
label = label:view(-1)

test_vecs = torch.zeros(testdata:size(1), batchsize, outputsize,1,1)
for i = 1, test_vecs:size(1) do
	test_vecs[i]:copy(model_p:forward(testdata[i]))
end

test_vecs = test_vecs:view(-1, outputsize,1,1)
testlabel = testlabel:view(-1)

-- Now train the new model with data_vecs and label
model_t = nn.Sequential()
model_t:add(nn.Reshape(outputsize*1*1))
model_t:add(nn.Linear(outputsize*1*1, 200))
model_t:add(nn.ReLU())

model_t:add(nn.Linear(200, 7))
model_t:add(nn.ReLU())

model_t:add(nn.LogSoftMax())
-- -- $$$ Step 4: Train added layers
criterion = nn.ClassNLLCriterion()
confusion = optim.ConfusionMatrix(params.numclasses)

model_t = traincnn(model_t, data_vecs, label, criterion)

-- goto theVeryEnd
-- -- $$$ Step 5: test
testcls(model_t, data_vecs, label)
testcls(model_t, test_vecs, testlabel)

print('Time consuming ' .. sys.clock() - starttime .. 's.')
torch.save(params.rundir .. '/model.net', model)

::theVeryEnd::